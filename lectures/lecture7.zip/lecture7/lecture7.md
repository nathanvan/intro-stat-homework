Stat 202: Lecture 7 (covers pp. 100-111) 
========================================================
author: Nathan VanHoudnos
date: 10/8/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #8 results 
3. Lecture 7 (covers pp. 100-111)  

Homework #2 Grades
=================
![plot of chunk unnamed-chunk-1](lecture7-figure/unnamed-chunk-1.png) 

```
mean   76% 
median 85% 
```

****

Some comments: 

 * 4 of the 10 people with zeroes also scored zero on HW 1. 
 * A plurality those who handed in the assignment got the Obama question wrong.
 

The Obama Solution
==================
The temptation is to 
 * mention in passing that association does not imply causation, but then 
 * answer the President's question as if correlation did imply causation.
 
If you succumbed to the temptation, you recieved zero points. **You must hold the line!**

The breakdown of points awarded (conditional on handing in the assignment):

0|5|10 
---|---|--- 
48%|11%|41% 




Agenda 
==========
1. Homework comments
2. Checkpoint #8 results 
3. Lecture 7 (covers pp. 100-111)  

Checkpoint #8 results 
======================
* 70 out of 76 students
* average score 76% correct 


Checkpoint #8 Question 4
======================
Four students attempt to register online at the same time for an Introductory Statistics class that is full. Two are freshmen and two are sophomores. They are put on a wait list. Prior to the start of the semester, two enrolled students drop the course, so the professor decides to randomly select two of the four wait list students and gives them a seat in the class.

What is the probability that both students selected are freshmen?

Answer -- With order
=====
$$ S = \begin{Bmatrix}
 & F1F2 & F1S1 & F1S2 \\
F2F1 &  & F2S1 & F2S2 \\
S1F1 & S1F2 & & S1S2 \\
S2F1 & S2F2 & S2S1 & \\
\end{Bmatrix} $$

$$ A = \{ F1F2, F2F1 \} $$                      

$$ P(A) = \frac{|A|}{|S|} = \frac{2}{12} = \frac{1}{6}$$

Answer -- Without order
=====
$$ S = \begin{Bmatrix}
 & F1F2 & F1S1 & F1S2 \\
 &  & F2S1 & F2S2 \\
 &  & & S1S2 \\
 &  & & \\
\end{Bmatrix} $$

$$ A = \{ F1F2 \} $$                      

$$ P(A) = \frac{|A|}{|S|} = \frac{1}{6}$$


Agenda 
==========
1. Homework comments
2. Checkpoint #8 results 
3. Lecture 7 (covers pp. 100-111)  

The complement
==============
The **complement** of $A$ is the event that "event $A$" does not occur

![a](image013-dbl.gif)

"$A^c$" and "$\text{not} A$" are both used for the complement 


Probability Rules!
=================
Let $S$ be the sample space, $A$ any event, and $A^c$ its complement.

1. $0 \le P(A) \le 1$

2. $P(S) = 1$

3. $P(A^c) = 1 - P(A)$

The complement rule
===================

Note that 

$$P(A^c) = 1 - P(A)$$

implies that 

$$P(A) = 1 - P(A^c)$$

**The probability of an event is sometimes easire to find via its complement.**

Complement Rule Example
=======================

Blood type | O | A | B | AB |
-----------|---|---|---|----|
Probability| .44 | .42 | .10 | .04| 

A person with 
 * type A can donate to type A or AB.
 * type B can donate to type B or AB.
 * type AB can donate to type AB only.
 * type O blood can donate to anyone.

What is the probability that a randomly chosen person **cannot** donate blood to everyone? 

Complement Rule Example
=======================
incremental: true 

What is the probability that a randomly chosen person **cannot** donate blood to everyone? 

Blood type | O | A | B | AB |
-----------|---|---|---|----|
Probability| .44 | .42 | .10 | .04| 

Let $D$ be the event that a randomly chosen person **can** donate blood to everyone. 
Let $D^c$ be that they cannot.

$$ P(D^c) = 1 - P(D) $$

$$ P(D^c) = 1 - .44 $$

$$ P(D^c) = .56 $$

Complement Rule Example
=======================

![a](image014-dbl.gif)


Before getting to more rules...
================================

* we will define a few technical terms:
   * "or"
   * "and"
   * disjoint, and 
   * independent 


The definition of "or"
=================

> When a parent says to his or her child in a toy store 
> "Do you want toy A or toy B?", this means that the child is 
> going to get only one toy and he or she has to choose between them. 
> Getting both toys is usually not an option.

However, in the language of probability: 

 * **"OR" means either one or the other or both.**
 * $P( A \text{ or } B)$ = $P( \text{Event A, Event B, or both} )$ 

The definition of "and"
=================
And is simpler: 
 * **"and" means both.**
 * $P( A \text{ and } B)$ = $P( \text{Event A and Event B both occur} )$ 

Disjoint (AKA mutually exclusive)
========
![a](image015-dbl.gif)
**Disjoint** 
 * $A$ can happen, 
 * $B$ can happen, but
 * $P(A \text{ and } B) = 0$ 
 
***

![a](image016-dbl.gif)
**not** disjoint
 * $A$ can happen, 
 * $B$ can happen, and
 * $P(A \text{ and } B) > 0$ 

Example
=======
incremental: true 

A couple is planning to have 3 children. 

$$\begin{aligned}
S = \{ & BBB, BBG, BGB, GBB, \\
       & GGB, GBG, BGG, GGG \}
       \end{aligned}$$

Consider the following two events: 
 * A : the middle child is a girl
 * B : the three children are the same gender

**Are these events disjoint?**

* No. $GGG$ is in both events. 

Example
=======
incremental: true

A couple is planning to have 3 children. 

$$\begin{aligned}
S = \{ & BBB, BBG, BGB, GBB, \\
       & GGB, GBG, BGG, GGG \}
       \end{aligned}$$

Consider the following two events: 
 * C : exactly one of the three children is a girl 
 * D : exactly one of the three children is a boy 

**Are these events disjoint?**

* Yes. No outcomes overlap.

Independence
============
From p. 104: 

> Two events A and B are said to be independent if the fact 
  that one event has occurred does not affect the probability 
  that the other event will occur. If whether or not one event
  occurs does affect the probability that the other event will occur, 
  then the two events are said to be dependent.

Example #1
=========
incremental: true

A woman's pocket contains two quarters and two nickels. She randomly extracts one of the coins and, after looking at it, replaces it before randomly picking a second coin.

Let $Q1$ be the event that the first coin is a quarter and $Q2$ be the event that the second coin is a quarter.

Are $Q1$ and $Q2$ independent events?

**Yes.**

Example #2
=========
incremental: true

A woman's pocket contains two quarters and two nickels. She randomly extracts one of the coins and, after looking at it, sets it on the table. She then randomly picks a second coin from her pocket.

Let $Q1$ be the event that the first coin is a quarter and $Q2$ be the event that the second coin is a quarter.

Are $Q1$ and $Q2$ independent events?

**No.** There are fewer quarters the second time.

Examples #3
==================
incremental: true

A family has 4 children, two of whom are selected at random. 

Let $B1$ be the event that one child has blue eyes, and $B2$ be the event that the other chosen child has blue eyes. 

Are $B1$ and $B2$ independent? 

**No.** Eye color is hereditary, so whether or not one child is blue-eyed will increase or decrease the chances that the other child has blue eyes, respectively.

Disjoint and Independence
=========================
incremental: true

Recall the definition of independence: 

> Two events A and B are said to be independent if the fact 
  that one event has occurred does not affect the probability 
  that the other event will occur. If whether or not one event
  occurs does affect the probability that the other event will occur, 
  then the two events are said to be dependent.

Can two events be both disjoint and independent? 

* **No.** If $A$ and $B$ are disjoint, knowing $A$ occurred implies that $P(B) = 0$.


Disjoint and Independence
=========================
incremental: true

Roughly 7% of American males in U.S. have some sort of color blindness.

Suppose that a medical researcher selects one American male at random.

Let $A$ represent the event ’the selected male is color blind’.

Let $B$ represent the event ’the selected male is not color blind’.

Are $A$ and $B$ disjoint? Are $A$ and $B$ independent?

Disjoint: **yes**; independent: **no**



Disjoint and Independence
=========================
incremental: true

Now, suppose the medical researcher selects two American males at random.

Let $A$ represent the event 'the first male is color blind'.

Let $B$ represent the event 'the second male is not color blind'.

Are $A$ and $B$ disjoint? Are $A$ and $B$ independent?

Disjoint: **no**; independent: **yes**


Special case probability rules
=================

If $A$ and $B$ are **disjoint**, then 

  $$ P(A \text{ or } B ) = P(A) + P(B) $$

If $C$ and $D$ are **independent**, then

  $$ P(C \text{ and } D ) = P(C) \times P(D) $$
  
**We will learn generalizations of these rules soon.**

Example: Addition rule
==============
incremental: true

Blood type | O | A | B | AB |
-----------|---|---|---|----|
Probability| .44 | .42 | .10 | .04| 

What is the probability that a randomly chosen person is a potential donor for a person with blood type A? 

 * Recall that only Type A and Type O can donate to Type A. 
 * Type A and Type O are **disjoint**
 $$\begin{aligned}
 P( A \text{ or } O ) & = P(A) + P(O) \\
                      & = .42 + .44 = .86
\end{aligned}$$



Example: Multiplication rule
=======
incremental: true

According to the most updated data gathered by the American Association of Suicidology, 80% of suicides in the U.S. are committed by men.

Two suicide cases are selected at random. What is the probability that both suicides were men? 

 * The first case is **independent** of the second:
 
   $P(M \text{ and } M) = .8 \times .8 = 0.64$ 
 

Combo: Mult. and Addition rules
=======
incremental: true

According to the most updated data gathered by the American Association of Suicidology, 80% of suicides in the U.S. are committed by men.

Two suicide cases are selected at random. What is the probability that both suicides were 
committed by a person **of the same gender**?

 * The events $MM$ and $FF$ are **disjoint**:
   $P(MM \text{ or } FF) = P(M \text{ and } M) + P(F \text{ and } F)$
   
 * The first and second cases are **independent**:
$$\begin{aligned}
P(MM \text{ or } FF) & = P(M \text{ and } M) + P(F \text{ and } F) \\ 
       & = .8 \times .8 + .2 \times .2 = .68 
\end{aligned}$$ 

Combo: Mult. and Complement 
===========================
> A patient with blood type O desperately needs a blood transfusion. Since a person with blood type O can receive blood only from another person who has blood type O, the blood bank decides to choose 10 donors at random and hope that at least one of them has blood type O. 

Let event $O1$ denote the first person has blood type O, and so on for $O2$ to $O10$. Let event $L$ denote the event "at least one has blood type O". 

Find $P(L)$.

Combo: Mult. and Complement 
===========================
Complement rule: $P(L) = 1 - P(L^c)$

* The complement of $L$ is 
   + "none of the ten have blood type O."
   + i.e. $\text{not } O1$, $\text{not } O2$, $\dots$, and $\text{not } O10$

Therefore: 
$$P(L^c) = P(\text{not } O1, \text{not } O2, \dots, \text{ and } \text{not } O10)$$

Combo: Mult. and Complement 
===========================
$$P(L^c) = P(\text{not } O1, \text{not } O2, \dots, \text{ and } \text{not } O10)$$

* All of these events are **independent** and **equally likely**

$$\begin{aligned}
P(L^c) & = P(\text{not } O1, \text{not } O2, \dots, \text{ and } \text{not } O10) \\
       & = P(\text{not } O1) \times P(\text{not } O2) \times \dots \times P(\text{not } O10) \\
       & = \left[ P(\text{not } O1) \right]^{10}
\end{aligned}$$


Combo: Mult. and Complement 
===========================
Blood type | O | A | B | AB |
-----------|---|---|---|----|
Probability| .44 | .42 | .10 | .04| 

Let event $O1$ denote the first person has blood type O, and so on for $O2$ to $O10$. Let event $L$ denote the event "at least one has blood type O". Find $P(L)$.

$$\begin{aligned} 
P(L) & = 1 - P(L^c) \\
     & = 1 - \left[ P(\text{ not } O1) \right]^{10} \\
     & = 1 - \left[ 1 - P(O1) \right]^{10} \\
     & = 1 - \left[ 1 - .44 \right]^{10} = 0.9969
\end{aligned}$$


An important document 
=========================
incremental: true

Service A delivers on-time in 90% of cases, Service B in 80% of cases, and furthermore, 75% of the time, both A and B are on time. 

Let events $A$ and $B$ represent on-time delivery.

Which is the probability that a document will be on time if we send a copy with Service A and another with Service B? 

$$\begin{aligned} P(A \text{ and } B) & & 
\text{ or } & &
P(A \text{ or } B)
\end{aligned}$$

**$P(A \text{ or } B)$** ... Are events $A$ and $B$ disjoint? 

**No.** We need a new addition rule.

$$P(A \text{ or } B) = ?$$

Derive the general addition rule
=======

![plot of chunk unnamed-chunk-4](lecture7-figure/unnamed-chunk-4.png) 
***

with a Venn diagram.

$$\begin{aligned}
P(A) & = .90 \\
P(B) & = .80 \\
P(A \text{ and } B) & = .75
\end{aligned}$$

$$\begin{aligned}
P(A & \text{ or } B)   \\
    & = P(A) + P(B) - P(A \text{ and } B) \\
    & = .90 + .80 - .75 \\
    & = .95
\end{aligned}$$


Venn Diagrams are powerful
==========================
![plot of chunk unnamed-chunk-5](lecture7-figure/unnamed-chunk-5.png) 
***
For example:

$$\begin{aligned}
P(A & \text{ or } B)   \\
    & = P(A) + P(B) - P(A \text{ and } B) \\
    & = P(A) + P(B \text{ and } A^c) \\
    & = P(A \text{ and } B^c) + P(B) 
\end{aligned}$$ 

Useful when either given or need to find the probability that **only** A occurs ($P(B \text{ and } A^c)$). 

A Venn diagram as a table (pp. 109-110)
===============
![a](prob_table_explained-dbl.png)

Summary of Lecture 7
====================
Let $S$ be the sample space, $A$ any event, $A^c$ its complement, and $B$ another event. 

1. $0 \le P(A) \le 1$

2. $P(S) = 1$

3. $P(A^c) = 1 - P(A)$

4. $P(A \text{ or } B ) = P(A) + P(B) - P(A \text{ and } B)$

5. If and only if $A$ and $B$ are **independent**, then

  $$ P(A \text{ and } B ) = P(A) \times P(B) $$
  
