Stat 202: Lecture 9 (covers pp. 118-123)  
========================================================
author: Nathan VanHoudnos
date: 10/13/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #10 results 
3. Lecture 9 (covers pp. 118-123)  

Homework comments
==================

Agenda 
==========
1. Homework comments
2. Checkpoint #10 results 
3. Lecture 9 (covers pp. 118-123) 

Checkpoint #10 results 
==================
to fill in


Agenda 
==========
1. Homework comments
2. Checkpoint #10 results 
3. Lecture 9 (covers pp. 118-123)  

Probability Rules! 
==================
Let $S$ be the sample space, $A$ any event, $A^c$ its complement, and $B$ another event. 

1. $0 \le P(A) \le 1$

2. $P(S) = 1$

3. $P(A^c) = 1 - P(A)$

4. $P(A \text{ or } B ) = P(A) + P(B) - P(A \text{ and } B)$

5. If and only if $A$ and $B$ are **independent**, then

  $$ P(A \text{ and } B ) = P(A) \times P(B) $$

General multiplication rule
============================
Recall the definition of conditional probability: 

$$P(A|B) = \frac{P(A \text{ and } B )}{P(B)} $$

Therefore, for all events $A$ and $B$:

$$P(A \text{ and } B )= P(A|B) \times P(B) $$


Why a generalization? 
============================
The general rule: 

$$P(A \text{ and } B ) = P(A|B) \times P(B) $$

Recall that $A$ is **independent** of $B$ if and only if 

$$P(A|B) = P(A)$$

Therefore, if $A$ is **independent** of $B$, 

$$
\begin{aligned}
P(A \text{ and } B ) & = P(A|B) P(B) \\
  & = P(A) P(B) 
\end{aligned}
$$

which is rule #5. 


Probability Rules! 
==================
Let $S$ be the sample space, $A$ any event, $A^c$ its complement, and $B$ another event. 

1. $0 \le P(A) \le 1$

2. $P(S) = 1$

3. $P(A^c) = 1 - P(A)$

4. $P(A \text{ or } B ) = P(A) + P(B) - P(A \text{ and } B)$

5. $P(A \text{ and } B ) = P(A|B) P(B)$

6. **Independent:**  if and only if $P(A|B) = P(A)$.


General multiplication rule
============================
The order of conditioning does not matter...

$$
\begin{aligned}
P(A|B) & = \frac{P(A \text{ and } B )}{P(B)} \\
P(B|A) & = \frac{P(A \text{ and } B )}{P(A)} 
\end{aligned}$$

Therefore:

$$
P(A \text{ and } B ) = P(A|B) P(B) = P(B|A) P(A)
$$


More than two events: 
========================
In later courses you will work with objects like this: 

$$\begin{aligned}
P(X, & \mu, \text{ and } \sigma) \\
 & = P(X, \big\{ \mu \text{ and } \sigma \big\} ) \\
 & = P(X|\big\{ \mu \text{ and } \sigma \big\}) P( \big\{ \mu \text{ and } \sigma \big\}  ) \\
 & = P(X| \mu, \sigma ) P(\mu|\sigma)P(\sigma)  )  
\end{aligned}$$

This **chaining** of the general multiplication rule is important for: 
  * Hierarchical Linear Models (HLM)
  * All of **Bayesian** statistics


An example
==========
In a certain region, one in every thousand people (0.001) of all individuals are infected by the HIV virus that causes AIDS. Tests for presence of the virus are fairly accurate but not perfect. If someone actually has HIV, the probability of testing positive is 0.95. 

Let $H$ denote the event of having HIV, and $T$ the event of testing positive.

What is the probability that someone chosen at random tests has HIV and tests positive? 

$P(H) = 0.001$ : "0.001 of have HIV:"   

$P(T|H) = 0.95$ : "If someone actually has HIV, the probability of testing positive is 0.95."

Probability Trees
==================



Checkpoint concepts
====================
* General multiplication rule 
* More notation
* Probability trees
* Bayes Rule


Final
======

