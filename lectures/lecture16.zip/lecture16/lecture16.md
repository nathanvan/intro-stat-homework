Stat 202: Lecture 15 (covers pp. 171-187)   
========================================================
author: Nathan VanHoudnos
date: 10/31/2014
transition: none

Agenda 
==========
1. Checkpoint #17 comments
2. Lecture 16 (covers pp. 171-187)   

Checkpoint #17
==============
What is the average percentage correct for this activity?
* 60% correct


Question 1 Checkpoint #17
=============
Which of the following statements about the sampling distribution of the sample mean, x-bar, is not true?

* a) The distribution is normal regardless of the shape of the population distribution, as long as the sample size $n$ is large enough.         
* b) The distribution is normal regardless of the sample size, as long as the population distribution is normal.         
* c) The distribution's mean is the same as the population mean.         
* d) The distribution's standard deviation is smaller than the population standard deviation.         
* e) All of the above statements are correct.         

Question 4 Checkpoint #17
=========================
Suppose that a candy company makes a candy bar whose weight is supposed to be 50 grams, but in fact, the weight varies from bar to bar according to a normal distribution with mean $\mu = 50$ grams and standard deviation $\sigma = 2$ grams.

If the company sells the candy bars in packs of 4 bars, what can we say about the likelihood that the average weight of the bars in a randomly selected pack is 4 or more grams lighter than advertised?

* a) There is no way to evaluate this likelihood, since the sample size (n = 4) is too small.     
* b-d) There is about a __ chance of this occurring.     
* e) It is extremely unlikely for this to occur; the probability is very close to 0.     


Agenda 
==========
1. Checkpoint #17 comments
2. Lecture 16 (covers pp. 171-187)   

Final part of course
====================
![a](big_picture_inference-dbl.gif)


Inference
=========
incremental: true

**Point estimation**
 * Estimating a population quantity with a statistic that is a single number. 
    + Over many experiments, the distribution of the point estimate is centered at the
    true value.
 * What is the average IQ at Northwestern University? 
    + $\bar{x}$ is a point estimator of $\mu$.
 * What proportion of white students attend Northwestern University?
    + $\hat{p}$ is a point estimator of $p$.
 
Inference
=========
incremental: true
 
**Interval estimation**
 * Estimating a population quantity with a statistic that is an **interval**. 
 * Two ways to estimate an interval: 
    + **Option F**: If we repeat the experiment over and over, 95% of intervals will contain the true value.     
    + **Option B**: If we do the experiment once, the probability that the true value is contained within the interval is 95%.
    
 * Option F and Option B are **similar**, but **not the same**.
 
Option F: Summary
=========
incremental: true
 
If we:
* know the value of $\sigma$, and 
* can take at least $n \ge 30$ independent samples

then the CLT implies that 

$$P( \bar{X} - 2 \sigma/n \le \mu \le \bar{X} + 2 \sigma/n) = .95$$

and that is a good and useful thing. It means that 

> 95% of confidence intervals you create will contain the true value. 

Option F: Illustration
======================
![a](NYW-confidence-interval-quad.png)

(to replace with R code...)

Option F: Warning
=========
incremental: true

$$P( \bar{X} - 2 \sigma/n \le \mu \le \bar{X} + 2 \sigma/n) = .95$$

This probability statement, **however**, is only true when $\bar{X}$ is currently **unknown**, i.e. 

$\bar{X} \sim N(\mu, \sigma^2/n)$ 

If we **do the experiment** we have, say, 

$\bar{x} = 100$

which is a **draw** from $\bar{X}$. 


Option F: Warning
=========
incremental: true

$$P( \bar{X} - 2 \sigma/n \le \mu \le \bar{X} + 2 \sigma/n) = .95$$

If we **do the experiment** we have, say, $\bar{x} = 100$ with $2 \sigma/n = 3$ then 

$$\begin{aligned}
P( \bar{x} - & 2 \sigma/n \le \mu \le \bar{x} + 2 \sigma/n)  \\
  & = P( 100 - 3 \le \mu \le 100 + 3 ) \\
  & = P( 97 \le \mu \le 103 ) 
\end{aligned}$$ 

That is weird; $\mu$ is just a number -- **it does not have a distribution**.

Option F: Warning
=========
incremental: true

The CLT implies that:
$$P( \bar{X} - 2 \sigma/n \le \mu \le \bar{X} + 2 \sigma/n) = .95$$

Which is not:
$\begin{aligned}
P( \bar{x} - & 2 \sigma/n \le \mu \le \bar{x} + 2 \sigma/n) = P( 97 \le \mu \le 103 ) 
\end{aligned}$

Remember that $\mu$ does not have a probability distribution. 

If $\mu = 100$, then $P( 97 \le 100 \le 103 )  = 1$     
If $\mu = 95$, then $P( 97 \le 95 \le 103 )  = 0$

**The interval either contains $\mu$ or it does not.** 

Option F: Warning
==================
left: 40%

![a](Yoda_Empire_Strikes_Back-dbl.png)
***
Do
$$\begin{aligned}
P( \bar{X} & - 2 \sigma/n \le \mu \le \bar{X} + 2 \sigma/n) \\
           & = .95
\end{aligned}$$

or do not. There is no try: 

$$\begin{aligned}
P( \bar{x} & - 2 \sigma/n \le \mu \le \bar{x} + 2 \sigma/n) \\
           & \ne .95
\end{aligned}$$

$\bar{X}$ is random. You can "reverse" it to say something about $\mu$. 
$\bar{x}$ is **not** random. You cannot say anything about $\mu$.

Inference
=========
**Interval estimation**
 * Estimating a population quantity with a statistic that is an **interval**. 
 * Two ways to estimate an interval: 
     + **Option F: Confidence Intervals**: If we repeat the experiment over and over, 95% of intervals will contain the true value.
     + **Option B: Credible Intervals**: The probability that the true value is contained within the interval is 95%.

Confidence v. Credible Intervals
================================

This is awkward: 

* Statistician: The 95% confidence interval for $\mu$ is $[97,103]$. This means that over many experiments, about 95% of the intervals calculated in this way will contain the true value $\mu$.

* Normal person: Okay. What's the probability that **this** interval $[97,103]$ contains $\mu$?

* Statistician: I don't know. 


Confidence v. Credible Intervals
================================
incremental: true

Many people are therefore tempted to do the following **$^\text{[citation needed]}$**:  

* Statistician: The 95% confidence interval for $\mu$ is $[97,103]$. This means that over many experiments ... 

* Normal person: Okay. What's the probability that **this** interval $[97,103]$ contains $\mu$?

* Statistician: **Well, technically this isn't the right answer, but you can think of it as 95% (more or less)**. 

> This is a lie. An "easy" lie, but a lie! 

Credible intervals
==================
Recall that:  
 * $\bar{X}$ is random. You can "reverse" it to say something about a non-random $\mu$.     
 * $\bar{x}$ is **not** random. You cannot say anything about a non-random $\mu$. 

What if $\mu$ was modeled as, itself, random? 

Credible intervals
==================
If $\mu$ were random, then we could use Bayes Rule to update our beliefs about $\mu$ after we have seen the data. 

Therefore, we can do this 
$$\begin{aligned}
P( 97 \le \mu \le 103 \quad | \quad \text{data})
\end{aligned}$$
i.e., the probability that $\mu$ is contained in the interval (once we have seen the data!), can be calculated. 

> Neither Stat 202 (nor most statistics textbooks!) teach it. **Take a Bayesian statistics course!** 


Credible intervals (if time)
==================
How it works: 

1. Research the system that you are modeling.
2. Create a model for the data, given the parameter values: $P(x|\mu)$
3. Summarize your research (likely mean, uncertainty about what the mean is) into a distribution for $\mu$. This is the **prior**: $P(\mu)$
3. Do the experiment and get the data: $x$
4. Use Bayes' Rule to reverse $P(x|\mu)$ to $P(\mu|x)$
5. Answer probability questions about what the values of $\mu$ **after having seen the data** are.


Inference
=========
**Interval estimation**
 * Estimating a population quantity with a statistic that is an **interval**. 
 * Two ways to estimate an interval: 
     + **Option F: Confidence Intervals**: If we repeat the experiment over and over, 95% of intervals will contain the true value.
     + **Option B: Credible Intervals**: The probability that the true value is contained within the interval is 95%.


More with Option F
==================
In Stat 202, we will focus on confidence intervals. 

If the data are normally distributed with an **unkonwn** mean $\mu$ and a **known** standard deviation $\sigma$, then, a 95% confidence interval for $\mu$ is 
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 
  
If the are distributed with an **unknown** mean $\mu$ and a **known** standard deviation $\sigma$, then, if $n \ge 30$, a 95% confidence interval is 
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 
  

More with Option F
==================
If you want a different confidence interval, you change the **2**. 

A 68% confidence interval: 
  * $\bar{x} \pm 1 \sigma /\sqrt{n}$ 

A 95% confidence interval:
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 

A 99.7% confidence interval:
  * $\bar{x} \pm 3 \sigma /\sqrt{n}$ 

**Note:** Higher levels of confidence have less precise intervals. 

More with Option F
==================
If you want a different confidence interval, you change the **2**. 

A 95% confidence interval:
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 

A $(1-\alpha) \times 100\%$ confidence interval:
  * $\bar{x} \pm z_{\alpha/2} \cdot \sigma /\sqrt{n}$ 

(on the board) 

**Definition:** $z_{\alpha/2} \cdot \sigma /\sqrt{n}$ is  the **margin of error**.


More with Option F
==================
If you want to plan a study, you solve for $n$ 

IQ scores are known to vary normally with a standard deviation of 15. How many students should be sampled if we want to estimate the population mean IQ at 99% confidence with a margin of error equal to 2?

(on board)


More with Option F
==================
If you want to plan a study with a margin of error $m$, you solve for $n$ 

$$n = \left( \frac{z_{\alpha/2} \cdot \sigma}{m} \right)^2$$

and then round up to the nearest integer.

**Note:** Higher values of $n$ give **more** precise intervals.



Option F Summary
==================
In Stat 202, we will focus on confidence intervals. 

If the data are normally distributed with an **unkonwn** mean $\mu$ and a **known** standard deviation $\sigma$, then, a 95% confidence interval for $\mu$ is 
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 
  
If the are distributed with an **unknown** mean $\mu$ and a **known** standard deviation $\sigma$, then, if $n \ge 30$, a 95% confidence interval is 
  * $\bar{x} \pm 2 \sigma /\sqrt{n}$ 

**Note:** The book covers cases with unknown standard deviation. We will not cover this yet.


A cold read exercise
=====================
Can I have two volunteers to read from a script? 

(Time permitting.)

A dialogue
============================
incremental: true

Person: Can you give me an interval that will contain $\mu$ with 95% probability? 

Stat F: Sure, I can give you a confidence interval. Over 100 replications of your experiment, 95% of the confidence intervals with contain $\mu$. 

Person: Sorry, I misspoke. I want to perform one experiment, calculate an interval, and know that there is a 95% chance that $\mu$ is in that interval. 

Stat F: [as a smarty-pants] Ah! I see that you have a common misconception of what a confidence interval is. Let me try to explain it again... 


A dialogue
============================
incremental: true

Person: [interrupting, frustrated] No, no, no. I am smart person who understood what you said. It is, however, clear to me that you do not understand what I am asking ...

[Enter Statistician B]

**Stat B**: Hi! I overheard you talking to my colleague that you want an interval that will contain $\mu$ with 95% probability? 

Person: Yes! Finally, a statistician who understands what I am asking!


A dialogue
============================
incremental: true

Stat F: [freaked out] Wait! Stop! He is the devil! 

Person: [confused] What, why? 

Stat F: He will use **calculus** and **computer programming**! 

Person: [confused stare] ?

Stat F: He will make you specify how you expect your experiment to turn out!

Person: [confused] Wouldn't you ask me the same questions for a sample size calculation? 

A dialogue
============================
incremental: true

Stat F: Yes, but he will actually use your opinions instead of ignoring them like I do! Your result might not be objective! It might be influenced by what you believe! 

Person: [confused stare] ?

**Stat B:** Ah, my dear colleague, but I will answer the question that is asked instead of insisting on answering a different question. 

**Stat B:** We do not want what you are selling. Be gone! 

[Stat F is so frustrated as to die an exaggerated theatrical death.]
