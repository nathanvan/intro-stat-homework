Stat 202: Lecture 5 (covers pp. 62-78) 
========================================================
author: Nathan VanHoudnos
date: 10/3/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Homework comments 
====================
**How to check if your HTML file is in the right format.**
   1. Knit HTML to create a fresh HTML file 
   2. Open the folder where you originally saved the .Rmd file. The HTML file will have been generated in that same folder. 
   3. Double-click the HTML file to open it in your browser. 
   4. Check that it displays nicely in your browser. 
   5. Submit the HTML file to BlackBoard

How many of you use MS Word? 
====================

**Optional:** Hand in a MS Word *.docx file instead

   1. Click the little triangle next to the Knit HTML button
   
   ![a](word-example.png)
   
   2. Click "Knit Word"
   3. Follow the directions to submit the HTML file, but submit the *.docx file 
      instead.
      

Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Checkpoint #4 results
==================
* to fill in 

**Notes** 
 

Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Big Picture 
==========
![a](big_picture_producing_data-dbl.gif)


Producing data
==============
In Statistics 202 we consider two parts: 

1. **Sampling** individuals from the population 
2. **Designing** a study to collect information about the sample 

Types of samples 
=========
  * **volunteer:** subjects volunteer
      + e.g. Online polls 

  * **convenience:** literally when convenience drives decisions 
      + e.g. Ask your friends to take a survey.
      
  * **systematic:** deterministic rules draw the sample
      + e.g. Pick every 10th name from a list.
      
  * **probability:** everyone in the **sampling frame** has a nonzero chance of being selected
      + e.g. Draw names out of a hat.
         
         
Types of samples (OLI p. 66)
================
incremental: true

To determine the musical preferences of all students at your 
university you post a music-lovers' survey on a university Internet bulletin board, asking students to vote for their favorite type of music

Volunteer / convenience / systematic / probability?

  * **volunteer sample:** individuals self-select to participate 
  * **often biased** results: self-selecting individuals likely to be from the extremes of a population
  * **cannot generalize** to other groups
    
Never trust an online poll 
==========================
 Time 100 **World's Most Influential person** 
   * online worldwide poll 
   * in 2008 Shigeru Miyamoto won
      + Miyamoto is Nintendo's top video game designer (Donky Kong, Super Mario Bros., 
        The Legend of Zelda, etc.)
      + This is **a biased result**.  
    
   * in 2009, moot won... 

Never trust an online poll 
==========================
From [Time.com (2009)](http://content.time.com/time/arts/article/0,8599,1894028,00.html):

> In a stunning result, the winner of the third annual TIME 100 poll and new owner 
> of the title World's Most Influential Person is moot. The 21-year-old college student 
> and founder of the online community 4chan.org, whose real name is Christopher Poole, 
> received 16,794,368 votes and an average influence rating of 90 (out of a possible 100) 
> to handily beat the likes of Barack Obama, Vladimir Putin and Oprah Winfrey. 
> To put the magnitude of the upset in perspective, it's worth noting that everyone moot 
> beat out actually has a job.


Moot, MarbleCake, also The Game
================================
From  [Inside the precision hack](http://musicmachinery.com/2009/04/15/inside-the-precision-hack/) by Paul Lamere:
![a](timehack.jpg) 

    
Music preferences continued
================
incremental: true

Stand outside the Student Union, across from the Fine Arts Building, and 
ask students passing by to respond to your question about musical preference.

Volunteer / convenience / systematic / probability?

* **convenience sample:** easy for the researcher to get responses
* often **subtly biased** results
    + proximity to the Fine Arts building might bias towards classical music
* difficult to generalize to other groups

Music preferences continued
================
incremental: true

Obtain a student directory with email addresses of all the university's students, and send the music poll to every 50th name on the list.

Volunteer / convenience / systematic / probability?

 * **systematic sample**  
 * no clear bias
 * **no proof** that the sample is unbiased 

Music preferences continued
================
Obtain a student directory with email addresses of all the university's students, and randomly sample, without replacement, 100 students. 

Volunteer / convenience / systematic / probability?

   * **probability sample**
   * If all 100 students respond, can prove that the sample is unbiased
   * If fewer respond, can bound the amount of **non-response bias**


Music preferences continued
================
incremental: true

Ask your professors for email rosters of all the students in your classes. Randomly sample some addresses, and email those students with your question about musical preference.

Volunteer / convenience / systematic / probability?

   * **convenience sample** even though random! 
   * **Design error** 
      + **sampling frame:** students in your classes 
      + **population of interest:** all students at your university  
      + mismatch leads to bias
   
Probability sampling plans
==========================
Formal ways to ensure that the sampling frame matches the population of interest: 

* simple random sampling
* stratified sampling
* cluster sampling
* multi-stage sampling

Simple Random Sampling (SRS)
======================
**Defining characteristics**
  * every individual in the sampling frame is equally likely to be selected 
  
**Useful when** 
  * the population of interest is small enough to be enumerated 

**Example**
  * Randomly picking 10 homework assignments to grade to check that the TA 
    and I are on the same page. 


Stratified sampling
===================
**Defining characteristics**
  * the population is naturally divided into groups
  * a SRS is drawn from each **strata** 
     
**Useful when** 
  * the groups and all their members can be enumerated 

**Example**
  * Sampling 20 high-school seniors from each high school in a given city

Cluster sampling 
================
**Defining characteristics**
  * the population is naturally divided into groups
  * a SRS **of groups** is drawn and all members of the group are included 
     
**Useful when** 
  * the groups and all their members can be enumerated 

**Example**
  * Sampling 20 high schools from a state to study graduation rates


Multi-stage sampling 
================
**Defining characteristics**
  * the population is naturally divided into groups
  * a SRS **of groups** is drawn and then 
  * a SRS **of members** of the selected groups are included 
     
**Useful when** 
  * the groups in a cluster sample are too big 

**Example**
  * Sampling 10 students from 20 high schools in a state

How staff rate the food in the hospital cafeteria?
==================================================
Which sampling plan is best? 

1. Ask the next 5 staff members who come out of the cafeteria.  
2. Ask the next 50 staff members who come out of the cafeteria.   
3. Take a random sample of 5 staff members from HR records and ask them. 
4. Take a random sample of 50 staff members from HR records and ask them. 

Why? 
====
**Bias** 
 * The people coming out of the cafeteria like the food 
   well enough to eat there. 
 * A random sample from HR records will also catch people who cannot stand the 
   cafeteria food

**Sample size**
  * The average opinions of five people will vary wildly depending on which five you select 
  * The average opinions of twenty five people will vary less

A sampling example
=============================
left: 30%

[Abraham Wald](http://en.wikipedia.org/wiki/Abraham_Wald)
![http://en.wikipedia.org/wiki/File:Abraham_Wald_in_his_youth.jpg](Abraham_Wald_in_his_youth.jpg)
***

 * Founder of [sequential analysis](http://en.wikipedia.org/wiki/Sequential_analysis) 
 * Immigrated to US when Germany invaded Austria in 1938
 * In WWII 
    + Allied bombers were being shot down by Axis powers
    + Military studied the planes that returned and 
      suggested adding additional armor to the places most damaged
    + Wald disagreed. **Why?**

A sampling example
=============================
left: 30%

[Abraham Wald](http://en.wikipedia.org/wiki/Abraham_Wald)
![http://en.wikipedia.org/wiki/File:Abraham_Wald_in_his_youth.jpg](Abraham_Wald_in_his_youth.jpg)
***
 * the sampling frame is **planes that returned** 
 * finding the common areas of damage on planes that return is not helpful 
 * Instead, find the common areas where the planes were **undamaged** and armor those!

**Key point**: if your sampling frame does not match your population of interest, you can run into trouble.
 
Producing data
==============
In Statistics 202 we consider two parts: 

1. **Sampling** individuals from the population 
2. **Designing** a study to collect information about the sample 

Study designs
=============
In Statistics 202 we consider types of studies

* **observational studies** 
   + the researcher observes the response variable 
   + the researcher observes explanatory variables
   + e.g. sample surveys

* **experimental study**
   + the researcher observes the response variable 
   + the researcher **changes** at least one explanatory variable
   + e.g. assigning subjects to the treatment or control group

Snack more when watching TV? 
========
incremental: true

Is this study observational / survey / experiment?

> Recruit participants for a study. While they are presumably waiting 
> to be interviewed, half of the individuals sit in a waiting room with 
> snacks available and a TV on. The other half sit in a waiting room with
> snacks available and no TV, just magazines. Researchers determine 
> whether people consume more snacks in the TV setting.

 * **experiment**: researched changed the TV variable

Snack more when watching TV? 
========
incremental: true

Is this study observational / survey / experiment?

> Recruit participants for a study. Give them journals to record hour by hour their activities the following day, including when they watch TV and when they consume snacks. Determine if snack consumption is higher during TV times. 

 * **observational**: researchers did not change a variable 


Observational studies
==============
* difficult to make causal claims because of 
   + **lurking variables**
   + **Simpson's paradox** 
   
* tempting to make causal claims based on 
  observation studies
   + Journalists, policy makers, and politicians often **want** a causal answer
   + sometimes you cannot answer their questions
   + **resist** the temptation to give a causal answer when the study 
     cannot support it 

Experimental Studies
====================
An experiment is of little use unless it is **randomized**.

Randomized experiments:
  * randomly assign treatment and control
  * **account for lurking variables** by balancing the distribution of the 
    lurking variable between the two groups
  * gold-standard for causal inference

Experimenting on people
=======================

People are very smart. 
  * If a participant can determine if they are in the treatment condition or the control condition, 
  * the **expectations** that person has for the treatment or the control
  * can **influence the response** of the participant.

**Expectations** can become a lurking variable in a randomized experiment involving people.
  * Placebo effect
  * Hawthorne effect 
  
The placebo effect
==================
Consider an experiment to test the effectiveness of Prozac for depression.

Participants are randomized into three groups:
 * a group receiving Prozac pills
 * a group receiving a pill that looks like Prozac but is made of inert ingredients
 * a group receiving no pills or other form of treatment.

**Placebo effect:**
 * the group taking fake pills will feel better. 

Experimental blinding
==================================

If **expectations** can become a lurking variable, conceal the treatment or control status.

* **blinded experiment**: placebos prevent a participant from knowing their treatment status 
   
* **double-blind experiment**:
   + neither the experimenter nor the participant knows the treatment status
   
   + e.g. if the psychologist measuring a participants depression believes the treatment
   works, then knowing that a patient was in the control group might influence the rating 
   of depression severity. 
   
Ethics in human experiments
===========================
**Institutionl Review Boards**
  + mandated by the federal government
  + weigh the risks to participants 
  + give (hopefully!) unbiased decisions on whether or not the design of 
    a particular experiment is ethical
  + **real consequences** for violating the IRB protocols
      + e.g. suspension of all federally funded grants / awards for **the whole university**. 
  
Check out [Northwestern's IRB](http://www.irb.northwestern.edu/) and their [free training](http://www.irb.northwestern.edu/training/citi).

Pitfalls in Experiments
========================

**Hawthorne effect:** people in an experiment behave differently from how they would normally behave

   * Experiments can **lack realism** AKA **lack ecological validity**
   
**non-compliance:** people in an experiment may refuse to follow directions 
   
   * subjects may refuse to take the treatment, or refuse to stay in the control group
   * too much non-compliance leads to **bias**
   
Summary
=======
Experiments are difficult to implement, but they can answer causal questions.

Observational studies cannot answer causal questions.

  * **Exception:** advanced techniques exist to take observational data and use it to 
  create something like an experiment. The causal claim, however, is still based on an 
  analogy to an experiment. 
     
