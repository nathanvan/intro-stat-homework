Stat 202: Lecture 5 (covers pp. 62-78) 
========================================================
author: Nathan VanHoudnos
date: 10/3/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Homework comments 
====================
* To fill in. 

 
Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Checkpoint #4 results
==================
* to fill in 

**Notes** 
 * 68 of 75 students have signed up on OLI
 * 64 of 68 took the Checkpoint
    + 1 student took Checkpoint \#2 instead
 * Average percent correct: **90%**
 * If you have questions, see me or Aaron

Agenda 
==========
1. Homework comments
2. Checkpoint #4 results 
3. Lecture 5 (covers pp. 62-78)  

Big Picture 
==========
![a](big_picture_producing_data-dbl.gif)


Producing data
==============
In Statistics 202 we consider two parts: 

1. **Sampling** individuals from the population 
2. **Designing** a study to collect information about the sample 

Types of samples 
=========
  * **volunteer:** subjects volunteer
      + e.g. Online polls 

  * **convenience:** literally when convenience drives decisions 
      + e.g. Ask your friends to take a survey.
      
  * **systematic:** deterministic rules draw the sample
      + e.g. Pick every 10th name from a list.
      
  * **probability:** everyone in the **sampling frame** has a nonzero chance of being selected
      + e.g. Draw names out of a hat.
         
         
Types of samples (OLI p. 66)
================
incremental: true

Determine the musical preferences of all students at your 
university. 

* Post a music-lovers' survey on a university Internet bulletin board, asking students to
vote for their favorite type of music
    * **volunteer sample:** individuals self-select to participate 
    * **often biased** results: self-selecting individuals likely to be from the extremes of a population
    * **cannot generalize** to other groups
    
Never trust an online poll 
==========================
 Time 100 **World's Most Influential person** 
   * online worldwide poll 
   * in 2008 Shigeru Miyamoto won
      + Miyamoto is Nintendo's top video game designer (Donky Kong, Super Mario Bros., 
        The Legend of Zelda, etc.)
      + This is **a biased result**.  
    
   * in 2009, moot won... 

Never trust an online poll 
==========================
From [Time.com (2009)](http://content.time.com/time/arts/article/0,8599,1894028,00.html):

> In a stunning result, the winner of the third annual TIME 100 poll and new owner 
> of the title World's Most Influential Person is moot. The 21-year-old college student 
> and founder of the online community 4chan.org, whose real name is Christopher Poole, 
> received 16,794,368 votes and an average influence rating of 90 (out of a possible 100) 
> to handily beat the likes of Barack Obama, Vladimir Putin and Oprah Winfrey. 
> To put the magnitude of the upset in perspective, it's worth noting that everyone moot 
> beat out actually has a job.


Moot, MarbleCake, also The Game
================================
From  [Inside the precision hack](http://musicmachinery.com/2009/04/15/inside-the-precision-hack/) by Paul Lamere:
![a](timehack.jpg) 

    
Types of samples (OLI p. 66)
================
incremental: true

Determine the musical preferences of all students at your 
university. 

* Stand outside the Student Union, across from the Fine Arts Building, and 
  ask students passing by to respond to your question about musical preference.
    * **convenience sample:** easy for the researcher to get responses
    * often **subtly biased** results
        + proximity to the Fine Arts building might bias towards classical music
    * difficult to generalize to other groups

Types of samples (OLI p. 66)
================
Determine the musical preferences of all students at your 
university. 

* Obtain a student directory with email addresses of all the university's students, and send the music poll to every 50th name on the list.
   * **systematic sample**  
   * no clear bias
   * **no proof** that the sample is unbiased 

Types of samples (OLI p. 66)
================
Determine the musical preferences of all students at your 
university. 

* Obtain a student directory with email addresses of all the university's students, and randomly sample, without replacement, 100 students. 
   * **probability sample**
   * If all 100 students respond, can prove that the sample is unbiased
   * If fewer respond, can bound the amount of **non-response bias**



Types of samples (OLI p. 66)
================
incremental: true

Determine the musical preferences of all students at your 
university. 

* Ask your professors for email rosters of all the students in your classes. Randomly sample some addresses, and email those students with your question about musical preference.
   * **convenience sample** even though random! 
   * **Design error** 
      + **sampling frame:** students in your classes 
      + **population of interest:** all students at your university  
      + mismatch leads to bias
   

Probability sampling plans
==========================
* simple random sampling
* stratified sampling
* cluster sampling
* multi-stage sampling


Producing data
==============
In Statistics 202 we consider two parts: 

1. **Sampling** individuals from the population 
2. **Designing** a study to collect information about the sample 




Checkpoint #5: Random Samples
==============
* unbiased property
* types
     + simple random sample
     + stratified sampling
     + multi-stage sampling 
     + convenience sampling
     + voluntary response sampling
* population of interest
* sampling frame
* design flaws 
     + sampling frame does not match the population of interest 

Checkpoint #6: Designing Studies 
=============================
* random assignment and causality 
* placebo
* Types of studies 
     + experiments 
         + causal gold standard 
         + blinding (single? and double)
     + observational studies
         + difficult to make causal claims
     
