Stat 202: Lecture 4 (covers pp. 48-61) 
========================================================
author: Nathan VanHoudnos
date: 10/1/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #3 results 
3. Lecture 4 (covers pp. 48-61)  

Homework comments 
====================
* To fill in. 

 
Agenda 
==========
1. Homework #1 comments
2. Checkpoint #3 results 
3. Lecture 4 (covers pp. 48-61)  

Checkpoint #3 results
==================
* to fill in 

**Notes** 

 
Agenda 
==========
1. Homework comments
2. Checkpoint #3 results 
3. Lecture 4 (covers pp. 48-61)  


Strength of Linear Relationships
===================

**Age v. Distance**
![a](scatterplot4-dbl.gif)

*** 
What is the effect of age on maximum legibility distance of a road sign? 
 
Qualitative description:
  * a negative, moderately strong linear relationship    
 
**Quantitative measures:**
  * correlation
  * linear regression
  
Correlation
===========

We will:
 * give a definition of the correlation $r$
 * discuss the calculation of $r$
 * explain how to interpret the value of $r$, and
 * talk about some of the properties of $r$.

Correlation: Defined
====================
To quote (p. 49): 

> The correlation coefficient $r$ is a numerical measure that measures 
> the strength and direction of a **linear relationship** between two 
> **quantitative variables**.

* Can correlation measure of a curvelinear relationship? **No**

* Can two categorical variables be correlated with one another? **No**

Correlation: Calculated
=======================
Let 
 * $y_i$ be the $i^{th}$ obs. of the response variable 
 * $\bar{y}$ be the mean of the response variable
 * $S_y$ the standard deviation of the response variable

Similary let $x_i$, $\bar{x}$, and $S_x$ be defined for the explanatory variable. The correlation is:
 
$$ r = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) $$

Correlation: Calculated
=======================
$$ r = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) $$

 * This is more of a pain to calculate than the the standard deviation! 
 * **No one** calculates it by hand
 * In this class, you 
    + will learn the properties of $r$
    + how to interpret it, and 
    + how to calculate it with R. 

Correlation: Properties
=======================


Linear regression
=====================
  

Correlation and Causation
=============================
![a](xkcd-correlation-dbl.png)
 * http://xkcd.com/552/




Answer question with a table:
=======================
* conditional row percent
* conditional column percent

Properties of correlation
==========================
* always b/t -1 and 1 
* invariant to units
* sensitivity to outliers
* interpretation of r = 0
* correlation v. causation and lurking variables
* correlation r versus slope b

Interpreting scatterplots
=========================
* compare two groups
* read sign of correlation off of the graph

Lurking varaibles 
=================
* simpson's paradox 
