Stat 202: Lecture 4 (covers pp. 48-61) 
========================================================
author: Nathan VanHoudnos
date: 10/1/2014
transition: none

Agenda 
==========
1. Lecture 3 comments
2. Homework comments
3. Checkpoint #3 results 
4. Lecture 4 (covers pp. 48-61)  

$$ \text{Example of } Q \rightarrow C : \text{Target}$$
================
From [Wikipedia](http://en.wikipedia.org/wiki/Target_Corporation): 

> Target is an American retailing company, founded in 1902 and headquartered
> in Minneapolis, Minnesota. It is the second-largest discount retailer in 
> the United  States,

* Their statistics team is lead by Andrew Pole
    + Keynote at 2010 Predictive Analytics World 
    + [How Target Gets the Most out of Its Guest Data to Improve Marketing ROI](http://rmportal.performedia.com/rm/paw10/gallery_01#1373) 
        + (examples start at 34:25) 

$$ \text{Example of } Q \rightarrow C : \text{Target}$$
===================

* **Prediction of pregnancy status**
    + Having babies is a crazy time in your life.
    + [“As soon as we get them buying diapers from us, they’re going to start buying everything else too."](http://www.nytimes.com/2012/02/19/magazine/shopping-habits.html?pagewanted=all&_r=0) -- Pole
    + Pole built a model to predict if a guest was 
        + pregnant and 
        + when she was due.
    + Very profitable! 


$$ \text{Example of } Q \rightarrow C : \text{Target}$$
======================

However, one customer's experience from the [NYTimes](http://www.nytimes.com/2012/02/19/magazine/shopping-habits.html?pagewanted=all&_r=0): 
        
> “My daughter got this in the mail!” he said. “She’s still in high school, 
> and you’re sending her coupons for baby clothes and cribs? Are you trying 
> to encourage her to get pregnant?”

$$ \text{Example of } Q \rightarrow C : \text{Target}$$
======================

But later...

> On the phone, though, the father was somewhat abashed. 
> “I had a talk with my daughter,” he said. “It turns out there’s been 
> some activities in my house I haven’t been completely aware of. 
> She’s due in August. I owe you an apology.”

More generally: Why study stats? 
==========================
From [Indeed.com/salary](http://www.indeed.com/salary)

![a](statistician-dbl.png)


Agenda 
==========
1. Lecture 3 comments
2. Homework comments
3. Checkpoint #3 results 
4. Lecture 4 (covers pp. 48-61)  


Homework comments 
====================
* To fill in. 

Why do I teach you R? 
==========================

From the [Revolution Analytics blog](http://blog.revolutionanalytics.com/2014/02/r-salary-surveys.html):

![a](languages-dbl.png)

 
Agenda 
==========
1. Lecture 3 comments
2. Homework comments
3. Checkpoint #3 results 
4. Lecture 4 (covers pp. 48-61)  


Checkpoint #3 results
==================
* to fill in 

**Notes** 


Agenda 
==========
1. Lecture 3 comments
2. Homework comments
3. Checkpoint #3 results 
4. Lecture 4 (covers pp. 48-61)  


Strength of Linear Relationships
===================

**Age v. Distance**
![a](scatterplot4-dbl.gif)

*** 
What is the effect of age on maximum legibility distance of a road sign? 
 
Qualitative description:
  * a negative, moderately strong linear relationship    
 
**Quantitative measures:**
  * correlation
  * linear regression
  
Correlation
===========

We will:
 * give a definition of the correlation $r$
 * discuss the calculation of $r$
 * explain how to interpret the value of $r$, and
 * talk about some of the properties of $r$.

Correlation: Defined
====================
To quote (p. 49): 

> The correlation coefficient $r$ is a numerical measure that measures 
> the strength and direction of a **linear relationship** between two 
> **quantitative variables**.

* Can correlation measure of a curvelinear relationship? **No**

* Can two categorical variables be correlated with one another? **No**

Correlation: Calculated
=======================
Let 
 * $y_i$ be the $i^{th}$ obs. of the response variable 
 * $\bar{y}$ be the mean of the response variable
 * $S_y$ the standard deviation of the response variable

Similarly let $x_i$, $\bar{x}$, and $S_x$ be defined for the explanatory variable. The correlation is:
 
$$ r = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) $$

Correlation: Calculated
=======================
$$ r = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) $$

 * This is more of a pain to calculate than the the standard deviation! 
 * **No one** calculates it by hand
 * In this class, you 
    + will learn the properties of $r$
    + how to interpret it, and 
    + how to calculate it with R. 

Correlation: Properties
=======================
$$ r = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) $$
           
* A correlation between **age** in years and **distance** in feet has what units? 
     + $x_i - \bar{x}$ units of years
     + $S_x$ units of years
     + $\frac{x_i - \bar{x}}{S_x} := \frac{\text{years}}{\text{years}} := \text{unitless}$ 

* **Changing the units (feet to inches) or (years to days) does not affect the correlation.**

Correlation: Properties
=======================
$$ 
\begin{aligned}
r & = \frac{1}{n-1} \sum_{i=1}^n 
           \left( \frac{x_i - \bar{x}}{S_x} \right) 
           \left( \frac{y_i - \bar{y}}{S_y} \right) \\
S_x & = \sqrt{ \frac{1}{n-1} \sum_{i=1}^n \left(x_i - \bar{x}\right)^2 }
\end{aligned}
$$

* You can prove that:
   + **$-1 \le r \le 1$**
   + $|r| = 1$ if and only if $y = a + xb$





Linear regression
=====================
  

Correlation and Causation
=============================
![a](xkcd-correlation-dbl.png)
 * http://xkcd.com/552/




Answer question with a table:
=======================
* conditional row percent
* conditional column percent

Properties of correlation
==========================
* always b/t -1 and 1 
* invariant to units
* sensitivity to outliers
* interpretation of r = 0
* correlation v. causation and lurking variables
* correlation r versus slope b

Interpreting scatterplots
=========================
* compare two groups
* read sign of correlation off of the graph

Lurking variables 
=================
* Simpson's paradox 
