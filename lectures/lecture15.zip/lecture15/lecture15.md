Stat 202: Lecture 15 (covers pp. 166-169)   
========================================================
author: Nathan VanHoudnos
date: 10/29/2014
transition: none

Agenda 
==========
1. Checkpoint #16 comments
2. Lecture 15 (covers pp. 166-169)   

Checkpoint #16
==============
To fill in. 


Agenda 
==========
1. Checkpoint #16 comments
2. Lecture 15 (covers pp. 166-169)   

Stat 202 focuses on
=========
Population Parameters

**Continuous**  
  * Population mean: $\mu$ 
  * Population standard deviation: $\sigma$

Categorical  
 * Population proportion: $p$
  
******  
Sample Statistics

**Continuous**
  * Sample mean: $\bar{x}$
  * Sample standard deviation: $s$
  
Categorical  
  * Sample proportion: $\hat{p}$



Height of Adult males
=========================
![plot of chunk unnamed-chunk-1](lecture15-figure/unnamed-chunk-1-1.png) 
****
Assume that the height of adult men is normally distributed with a mean of 69 in. and a standard deviation of 2.8 in. 

Height of Adult males
=========================
![plot of chunk unnamed-chunk-2](lecture15-figure/unnamed-chunk-2-1.png) 
****
Assume that the height of adult men is normally distributed with a mean of 69 in. and a standard deviation of 2.8 in. 

* Randomly select 15 men from the population and measure their heights: 

```
67.2 69.5 66.7 73.5 69.9 66.7 70.4 71.1 70.6 68.1 73.2 70.1 67.3 62.8 72.1
```


Height of Adult males
=========================
![plot of chunk unnamed-chunk-4](lecture15-figure/unnamed-chunk-4-1.png) 
****
Assume that the height of adult men is normally distributed with a mean of 69 in and a standard deviation of 2.8 inches. 

* Randomly select 15 men from the population and measure their heights: 
* Make a histogram of those randomly selected 15 men. 



Sample mean of Adult Males
=====================
left: 60%

![plot of chunk unnamed-chunk-5](lecture15-figure/unnamed-chunk-5-1.png) 
***
The **population** mean 
 * always 69 inches. 

Each **sample** mean 

```
69.3 69.7 68.5 70.2 68.5 69.2
```

Sample 15 men 1,000 times
=====================

```
69.3 69.7 68.5 70.2 68.5 69.2 70.6 67.9 69.1 68.7 67.8 67.6 69.3 70.6 69.5 69.9 70.2 69.1 69.2 68.1 69.1 69.7 69.9 68.5 67.7 69.8 69.6 68.2 69.5 68.2 68.9 69.5 69.3 69.3 69.6 69.3 69.8 68.5 68.6 68.2 69.8 70.4 68.5 67.6 69.1 69.7 68.4 70.2 68.7 68.6 68.7 68.8 69.2 70 68 68.9 69.7 68.6 69.6 68.7 68.4 68.8 68.5 68.4 68.1 68.5 68.7 69.6 68.2 68.7 68.4 69.9 70.3 68.6 69.7 68.3 69.2 68.5 68.1 68.8 69 68.3 69.5 68.5 67 69.1 68 69.1 68.4 69.9 69.5 68.4 70.5 69 69 69.4 69.1 68.9 67.9 69.1 69.4 70.3 68.6 69.8 68.8 69.1 68.8 69.1 69.2 70.9 68.2 68.9 68.8 68.8 69.2 70 68.6 68.4 68.3 69.6 69.2 68 69.4 69.5 69.1 69 69.3 70.1 68.8 69.1 69.2 69.1 69.4 69.8 69.4 69 70.4 68.5 68.3 70.8 69.1 70 70.3 67.9 70.4 67.9 68.6 69.6 67 68 68.6 68.4 68.4 69 69 68.8 70.5 68 67.8 69.6 70.7 68.7 69 69.9 69.1 69.6 68.2 69.6 69 70.2 69.4 69.6 70.6 70.7 70.2 69.7 69.7 69.3 69.3 69 68.9 70.4 68.8 69.5 69.3 68.5 68.9 68.3 69.5 69.6 70.5 69 69.5 68.9 68.5 69.3 70.1 69 68.4 68.8 68.5 68.2 68.6 68.2 69.5 69.3 67.4 70.4 69.2 69.4 69 69.5 68.1 68.7 69.3 70.4 68.1 68.1 68.2 67.5 68.6 69.3 69.3 68.8 68.5 68.4 68.8 69.1 69.1 69.2 68.4 69.8 69.6 68.7 68.5 68.8 68.6 68.3 69.2 69.5 68 69.1 68.7 67.7 68.6 69.9 69.5 68 70.6 68.9 68 69.7 68.8 69.7 69.6 68.4 69.1 69.6 69 68.8 68.2 68.9 68.7 69.9 67.9 70 69.1 68.9 68.4 68.7 68.6 69.1 68.3 68 68.8 69 69.4 68.4 70 68.5 69.9 68.8 70.4 69.4 69.1 70.2 69 68.8 69.2 69.5 68.5 68.9 70 69.3 68.9 69.2 67.7 68.9 68.2 70.7 68.8 69 69.4 69.6 69.4 68.7 68.5 67.8 68.8 68.9 69.2 69.1 69 67.6 68.5 68.5 69.4 68.7 68.8 69.1 69.9 68.7 70.3 69.2 68.9 69.6 68.8 69.7 69 69.4 68.9 69.7 68.4 69.1 66.8 69.5 68.4 70.3 68.9 68.5 69.4 69.7 67.5 69.8 69.5 68.4 68.8 69.2 69.1 69.7 70.4 68.4 67.9 69.6 67.3 69.3 69.1 68.8 68.2 68.9 69.4 69.6 68.7 68.7 69.6 69.1 68 68.6 69 68.7 69.2 69.6 67.4 68.5 68.8 69.3 69.7 70 68.6 68.5 68.3 69.2 67.6 68.3 69.2 68.4 69.9 68.9 68.2 69.3 68.2 69.4 68.7 70.5 69.1 69.3 68 68.3 68.4 68.2 68.8 70.3 68.9 68.6 69.4 70.3 68.6 68.3 69.9 69.3 67.9 69.6 69.7 67.9 68.8 69.1 68 67.4 69.7 68.4 69.8 69.2 69.1 68.1 68.5 69.7 69.3 69.7 69.3 69.5 67.4 69.2 70.5 69.6 69.3 69.9 68.5 70.3 69.5 69.8 68 68.4 68.6 68.4 66.9 68.9 68.2 68.6 68.9 69.1 71.1 68.5 69.2 69.6 70.5 69.3 68.9 68.7 69.7 70 69.2 69.1 69.7 68.9 69.4 68 69.2 68.1 71 68.9 69.1 67.9 69 67.5 69.1 68.8 68.2 68.7 69.4 68.3 69.2 68.4 68.2 68.7 67.1 69.3 69.1 69 69.1 68.4 69.4 69 68.4 68.7 68.8 68.7 71 68 67.9 69.1 69.4 69 69.7 70.7 67.2 69.7 69.3 67.6 69.1 69 67.7 69.2 69 70.4 69.4 69.8 68.1 68.7 68.4 68.2 68.5 69.9 68.4 68.8 68.5 69.3 68.9 69.5 68.5 69.5 67.8 70 68.5 68.4 69.6 66.9 68.7 69.5 69.7 68.9 68.5 69.3 69.2 68.6 68.6 67.8 68.3 70.2 69.4 70.6 69.4 67.9 69.1 68.9 69 68.6 69 69 70.2 68.7 69.3 68.2 68.5 68 69.6 69.6 67.4 69.8 69.1 70.3 67.7 69.5 70.2 69.8 68.5 70.6 68.3 69.5 68.9 68.3 69.1 69.7 69.7 68 69.5 68.4 69.7 69.6 68.4 68.7 69.2 68.8 69.8 67.9 70.2 68.9 68.1 69.7 68.8 67.7 68.5 67.8 70.4 70 68.8 68.6 69 69 67.7 68 67.9 68.9 69.4 68.2 68.6 69.6 70.2 68.2 69.1 68 69 69.3 69.6 68.6 69.4 68.5 68.5 69.6 69.2 69.6 68.8 68.3 69.1 69.8 69.6 69 69.2 70 69.1 68.8 69.6 69.4 69.5 69.7 67.6 68.5 69.2 68.8 69.2 69.9 70.1 70 69.8 69 69.1 70 68.6 69.6 70.4 69.2 69.4 69.3 68.9 69.5 69.5 68.8 69.4 69 68.1 68.9 68.6 69.2 68.3 69 67.8 69.9 69.8 68.4 69.1 69.9 67.6 69.2 68.8 69.4 69.4 68.2 70.4 68.6 67.7 69 68.4 68.2 69.1 69.7 69.2 68.1 69 69.7 68.8 68.3 68.7 68.4 67.9 69.3 69.7 69.3 69.2 69.5 69.7 69.3 68.8 69 67.9 70.1 69.8 69.6 69.5 69.5 69.2 67.8 68.7 70.1 67.5 69.8 69.1 67.9 70.1 67.5 68.7 68.8 69.9 70.3 69.4 68.3 69.9 69.5 68.7 68.7 68.3 69.6 69.2 69.6 69.6 69.9 68.7 69.7 68.6 68.6 69.5 69.4 67.6 68 68.6 68.7 68 69.6 68.3 69.5 68.2 69.1 68.7 68.5 69.5 69 68.8 70 69.6 69 67.8 70 68.6 67.8 69.1 69.1 68.3 69.6 69.6 70.3 68.8 67.9 69.5 68.6 68.7 69.1 69.1 68.4 69.7 69.6 68.1 70 68.8 68.1 69 68.3 68.7 69.5 68.8 69.9 69.5 68.6 68.5 69.8 69 69.4 68.3 68.8 68.2 69.1 68.6 68.7 68.8 68.4 69.4 69.2 68.5 68.9 70.2 68.6 69.3 67.3 69.4 68.5 68.6 70.3 68.9 67 68.4 69.4 68.4 70.4 69.3 69.3 69.9 69.4 69.5 69.6 68.5 69.1 68.7 68.1 68.6 69.7 67.9 70.1 68.5 70.7 69.7 69.2 69.4 69.6 69.7 68.5 68.1 70.1 69.7 68.1 69.1 69.4 69.5 68.4 69.2 69.2 69.5 70.4 69.4 69.4 69.2 68.3 68.4 68.1 69.4 69.2 67.5 67.3 68.7 69.9 69.1 69.3 70.2 68.9 68.4 67.9 68.4 70.1 68.7 69.5 69.5 68.6 69.3 70.3 68.8 69 67.7 67.3 69 68.5 69.3 69.1 68.5 66.5 69.2 69.2 69.4 69.3 69.6 67.4 68.7 69.3 69.3 68.5 69.8 69.4 69.5 69.2 68.5 68.6 68.6 69 68.8 69.8 69.5 69.1 68.8 68.6 67.4 68.7 66.6 69.3 68.3 68.4 68 69.4 68.1 68.2 68.2 68.7 68.4 69.3 70 69.1 69.1 68.6 68 68.7 68.8 69 68 69.4 68.4 68.4 68.8 68 67.6 69.5 68.2 69 66.9 70.4 68.8 68.6 68.5 68.4 70.5 67.6 68.8 69 68.5 68.7 67.6 68.6 69 68.5 67.5 68.1 68.5 69.9 69.8 69.3 69 69.2 69.3 69.7 69.9 69 69.9 69.3 68.6 69.2 68.7 70.2 69.3 69.1 68.3 68.7 69.5 69 69.2 68.9 68.4 67.8
```

A histogram of the sample means
================
left: 50% 

![plot of chunk unnamed-chunk-8](lecture15-figure/unnamed-chunk-8-1.png) 
******

* Randomly select 15 men from the population and measure their heights.
* Do this 1,000 times
* The distribution of the sample mean is close to the population mean (69 inches)


What if we took 50 men instead? 
===============================
incremental: true

**Average of 15 men**

![plot of chunk unnamed-chunk-9](lecture15-figure/unnamed-chunk-9-1.png) 
******
**Average of 50 men**

![plot of chunk unnamed-chunk-10](lecture15-figure/unnamed-chunk-10-1.png) 

Approximately normal (which?)
================
If $X$ is normally distributed with mean $\mu$ and variance $\sigma^2$ 

$$X \sim N( \mu, \sigma^2) $$

then the mean of a sample of $n$ **indepedent** draws from $X$ 

$$\bar{x} = \frac{1}{n} \left[x_1 + x_2 + \dots x_n \right]$$

is also normally distributed 

$$\bar{x} \sim N\left( \mu, \frac{\sigma^2}{n} \right)$$

If X is normal, then 
=====
$$\begin{aligned}
\bar{x} & = \frac{1}{n} \left[x_1 + x_2 + \dots x_n \right] &
  & & 
  \bar{x} & \sim N\left( \mu, \frac{\sigma^2}{n} \right)
  \end{aligned}$$

**Proof** 

1. The sum of two (or more) independent normal random variables is also normally distributed. 
2. A normal distribution is defined by its mean and variance. 

$$\bar{x} \sim N\left( E[\bar{x}], \text{Var}[\bar{x}] \right) $$

so find $E[\bar{x}]$ and $\text{Var}[\bar{x}]$ (on the board.)

Example 2: Radioactive Decay
=================================
left: 30%
incremental: true

![a](Bananen_Frucht.jpg)

(for scale)

***

Bananas are [radioactive](http://en.wikipedia.org/wiki/Banana_equivalent_dose).
 * In one gram of banana, 31 atoms of potassium-40 will decay every second. 
 * In a 150 gram banana
 $$150 * 31 = 4,650$$
  decay events happen per second. 

Example 2: Radioactive Decay
=================================

**Time between decays**
![plot of chunk unnamed-chunk-11](lecture15-figure/unnamed-chunk-11-1.png) 

***

The time between radioactive decay events follows an **exponential distribution**. 

* A large proportion of events happen quickly. 
* Rarely, you have to wait awhile for an event. 
* The wait times are independent of each other.

Example 2: Radioactive Decay
=================================
incremental: true

**Time between decays**
![plot of chunk unnamed-chunk-12](lecture15-figure/unnamed-chunk-12-1.png) 

***

Let's wait for a decay event and record the time it took: 

```
0.162
```

And again: 

```
0.254
```

And do this 50 times to make a histogram...


Example 2: Radioactive Decay
=================================
**Time between decays**
![plot of chunk unnamed-chunk-15](lecture15-figure/unnamed-chunk-15-1.png) 
***

The **time between decay events** follows an exponential distribution. 

For this sample, from this banana, the average wait time between events was 

```r
mean(draw50.1)
```

```
[1] 0.2116219
```
milliseconds. 


Example 2: Radioactive Decay
=================================
**Time between decays**
![plot of chunk unnamed-chunk-17](lecture15-figure/unnamed-chunk-17-1.png) 
***

The **time between decay events** follows an exponential distribution. 

> If we repeated this experiment with, say 1,000, additional bananas, what would the sampling distribution of the mean look like? 

More Bananas
===================
* Banana 1: Collect data for 50 events. Calculate the mean. 

```
0.212
```
* Banana 2: Collect data for 50 events. Calculate the mean. 

```
0.24
```
* ...
* Banana 1000: Collect data for 50 events. Calculate the mean. 

```
0.185
```



Something amazing is coming
===========================
***Wait for it.***


Banana denouement
===================
![plot of chunk unnamed-chunk-21](lecture15-figure/unnamed-chunk-21-1.png) 

****
The average wait time of 50 events is approximately

**NORMALLY DISTRIBUTED**

even though the distribution of the time between events looked **nothing** like a normal distribution. 


Bananas together
==================
![plot of chunk unnamed-chunk-22](lecture15-figure/unnamed-chunk-22-1.png) 
***
* The wait time is distributed as an exponential distribution. 


Bananas together
==================
![plot of chunk unnamed-chunk-23](lecture15-figure/unnamed-chunk-23-1.png) 
***
* The wait time is distributed as an exponential distribution. 

* The theoretical (population) mean wait time is 0.215 milliseconds


Bananas together
==================
![plot of chunk unnamed-chunk-24](lecture15-figure/unnamed-chunk-24-1.png) 
***
* The wait time is distributed as an exponential distribution. 

* The theoretical (population) mean wait time is 0.215 milliseconds

* The sample mean of 50 events is **normally distributed** around 0.215 milliseconds. 


The central limit theorem (CLT)
=========================
incremental: true

1. Draw $n$ **independent** samples from a distribution with a mean of $\mu$ and a standard deviation of $\sigma$. 

2. Calculate the sample mean $\bar{x} = \frac{x_1 + x_2 + \dots + x_n}{n}$. 

3. **CLT**: If $n \ge 30$, then for **any distribution** that you will encounter in practice, the **sample mean** is **normally distributed** with a mean of $\mu$ and a standard deviation of $\frac{\sigma}{\sqrt{n}}$.

$$ n \ge 30 \quad \Rightarrow \quad \bar{x} \sim N \left( \mu, \frac{\sigma^2}{n} \right)$$


Sir Francis Galton 
=====================================================
Inventor of Regression
![a](Francis_Galton_1850s.jpg)
1822-1911
***
From [Three-Toed Sloth](http://vserver1.cscs.lsa.umich.edu/~crshalizi/weblog/390.html):
> I know of scarcely anything so apt to impress the imagination as the wonderful form of cosmic order expressed by **the law of error**. A savage, if could understand it, would worship it as a god.

Back to bananas
===============
left: 30%
incremental: true

![a](Bananen_Frucht.jpg)

(for scale)

***
Which of the following are normally distributed? 

The average wait time calculated from 5 events,

1. with no repetitions. 
2. repeated for 30 bananas. 
3. repeated for 1,000 bananas. 

**None.** $n = 5$ for all cases. CLT is about the average of a large sample ($n \ge 30$), not a large number of averages. 

Back to bananas
===============
left: 60% 

1000 averages of $n=5$
![plot of chunk unnamed-chunk-25](lecture15-figure/unnamed-chunk-25-1.png) 
****

* The CLT does not apply for $n = 5$. 

* The histogram does not match the theoretical normal distribution.


Back to bananas
===============
left: 30%
incremental: true

![a](Bananen_Frucht.jpg)

(for scale)

***
Which of the following are normally distributed? 

The average wait time calculated from 50 events,

1. repeated for 100 bananas. 
2. repeated for 10 bananas. 
3. with no repetitions (just 1 banana).

**All.** $n = 50$ for all cases. CLT is about the average of a large sample ($n \ge 30$), not a large (or small!) number of averages. 


Using the CLT
=============
My father-in-law is a [potato farmer](http://www.wongpotatoes.com/aboutus.html):
![a](w05-dbl.jpg)

Using the CLT
=============
incremental: true

**Klamath Pearls**

![a](pearls5-dbl.jpg)

A small potato grown only in the Klamath Basin (near the OR/CA border)
****

* Like any potato, Klamath Pearls vary in size. 

* Assume that the average size of a Klamath Pearl is 50 grams with a standard deviation of 10 grams. 

* Note: the size of potatoes **does not** follow a normal distribution.


Using the CLT
=============
incremental: true

**Klamath Pearls**

![a](pearls5-dbl.jpg)

Average size is 50 grams with a standard deviation of 10 grams. 
****

Dan has a packing machine that puts potatoes into 1 lbs (450 g) and 5 lbs (2,250 g) bags. 

* the "1 lbs" bag has approximately 9 potatoes in it. 
* the "5 lbs" bag has approximately 45 potatoes in it.

Using the CLT
=============
incremental: true

**Klamath Pearls**

![a](pearls5-dbl.jpg)

Average size is 50 grams with a standard deviation of 10 grams. 

**** 
Dan is worried that one of his fields is producing smaller potatoes than it should be. 

He grabs a "1 lbs" bag with 11 potatoes in it and calculates the (sample) average potato size. 

Is the average potato size from a "1 lbs" bag normally distributed? 

  * **No.** $n = 11$


Using the CLT
=============
incremental: true

**Klamath Pearls**

![a](pearls5-dbl.jpg)

Average size is 50 grams with a standard deviation of 10 grams. 

**** 
Dan is worried that one of his fields is producing smaller potatoes than it should be. 

He grabs a "5 lbs" bag with 49 potatoes in it and calculates the (sample) average potato size. 

Is the average potato size from a "5 lbs" bag normally distributed? 

  * **Yes.** $n = 49$


Using the CLT
=============
incremental: true

**Klamath Pearls**

![a](pearls5-dbl.jpg)

Average size is 50 grams with a standard deviation of 10 grams. 

**** 
Dan picks a "5 lbs" bag with 49 potatoes in it. Its average potato weighs $\bar{x} = 42$ grams.

If the field is producing potatoes as it should, what is the probability that the average potato in this bag would weigh 42 grams or less? 

Using the CLT
===============
incremental: true

The average size of a Klamath pearl is 50 grams with a standard deviation of 10 grams. Dan picks a "5 lbs" bag with 49 potatoes in it. Its average potato weighs $\bar{x} = 42$ grams. If the field is producing potatoes as it should, what is the probability that the average potato in this bag would weigh 42 grams or less? 


Step 1. Identify population mean $\mu$, population standard deviation $\sigma$, sample size $n$, and sample mean. 

$\mu = 50$, $\sigma = 10$, $n = 49$, and $\bar{x} = 42$

Step 2. Does the CLT apply? 

**Yes.** $n \ge 30$ and each potato in the bag is likely independent.


Using the CLT
===============
incremental: true

If the field is producing potatoes as it should, what is the probability that the average potato in this bag would weigh at 42 grams or less? Recall: $\mu = 50$, $\sigma = 10$, $n = 49$, and $\bar{x} = 42$

Step 3. Find the sampling distribution of $\bar{x}$

Recall: $\bar{x} \sim N \left( \mu, \frac{\sigma^2}{n} \right)$ = $N \left( 50, \frac{10^2}{49} \right)$

i.e. a mean of 50 g and a standard deviation of $\sqrt{\frac{10^2}{49}} = 1.43$ grams.

Using the CLT
===============
incremental: true

If the field is producing potatoes as it should, what is the probability that the average potato in this bag would weigh 42 grams or less? Recall: $\mu = 50$, $\sigma = 10$, $n = 49$, $\bar{x} = 42$, and by CLT $\bar{x} \sim N(50, 1.43^2)$.

Step 4. Answer the question.  

$$P( \bar{x} \le 42 )$$

$$ = P( (\bar{x} - 50)/1.43 \le (42-50)/1.43 ) \\
= P(Z \le - 5.59) = 0$$ 

The field **is not** producing potatoes properly. 

Summary
=======

The **average** of something normally distributed is always normal.

The **average** of any independent draw greater than 30 is also always normal.


