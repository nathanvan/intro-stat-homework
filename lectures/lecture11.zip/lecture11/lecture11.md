Stat 202: Lecture 11 (covers pp. 138-155)   
========================================================
author: Nathan VanHoudnos
date: 10/17/2014
transition: none

Agenda 
==========
1. Homework comments
2. Checkpoint #12 results 
3. Lecture 11 (covers pp. 138-155)   

Homework comments
==================

Agenda 
==========
1. Homework comments
2. Checkpoint #12 result
3. Lecture 11 (covers pp. 128-155)  

Checkpoint #12 results 
======================
to fill in


Question 2 Checkpoint #12 
==========================
The random variable X, representing the number of accidents in a certain intersection in a week, has the following probability distribution:


```r
x     |    0|    1|    2|    3|    4|    5|
-------------------------------------------
P(X=x)| 0.20| 0.30| 0.20| 0.15| 0.10| 0.05|
```

By the third day of a particular week, 2 accidents have already occurred in the intersection. What is the probability that there will be less than a total of 4 accidents during that week?

Answer
======
incremental:  true

By the third day of a particular week, 2 accidents have already occurred in the intersection. What is the probability that there will be less than a total of 4 accidents during that week?



```r
x     |    0|    1|    2|    3|    4|    5|
-------------------------------------------
P(X=x)| 0.20| 0.30| 0.20| 0.15| 0.10| 0.05|
```

"Two accident have already occurred" implies that at least two accidents will occur this week. We condition on $X \ge 2$. 

The "less than a total of 4" implies $X < 4$

Therefore we want $P(X < 4|X \ge 2)$.

Answer
======
incremental:  true

By definition $P(X < 4|X \ge 2)$ is 

$$ P(X < 4|X \ge 2) = \frac{P( X < 4 \text{ and } X \ge 2 )}{P(X \ge 2)}$$

The only counts less than 4 and greater than or equal to 2 are 2 and 3:

$$ P( X < 4 \text{ and } X \ge 2 ) = P(X =2 ) + P(X = 3) $$


Answer
======
incremental:  true

By the third day of a particular week, 2 accidents have already occurred in the intersection. What is the probability that there will be less than a total of 4 accidents during that week?


```r
x     |    0|    1|    2|    3|    4|    5|
-------------------------------------------
P(X=x)| 0.20| 0.30| 0.20| 0.15| 0.10| 0.05|
```

$$\begin{aligned}
P(X < 4|X \ge 2) & = \frac{P(X =2 ) + P(X = 3)}{P(X \ge 2)} \\
 & = \frac{.2 + .15}{.20 + .15 +.10 +.05} \\
 & = \frac{.35}{.5} = .70
\end{aligned}$$


Agenda 
==========
1. Homework comments
2. Checkpoints #12 result
3. Lecture 11 (covers pp. 128-155)   
    + **Checkpoint 13: Expection and variance rules** (finish today, slides marked with R are review) 
    + Checkpoint 15: Normal random variables
  
(R) Expected value rules
====================
Let $Y = X + 6$ be a new random variable. 

![a](image056-dbl.gif) 

Is $E[Y] = E[X] + 6$?

$$\text{(R) Let } Y = X + a \quad E[Y] = ?$$
=========================
$$\begin{aligned}
E[Y] & = \sum y \cdot P(Y=y) \\
 & = \sum (x + a) \cdot P(X + a = x + a) \\
 & = \sum (x + a) \cdot P(X = x) \\
 & = \left( \sum x \cdot P(X=x) \right ) + \left( \sum  a \cdot P(X=x) \right) \\
 & = E[X] + a \cdot \left(\sum P(X=x) \right) \\
 & = E[X] + a 
\end{aligned}$$


(R) Expected value rules
====================
Let $Y = 4X$ be a new random variable. 

![a](image058-dbl.gif)

Is $E[Y] = 4 \cdot E[X]$?

$$\text{(R) Let } Y = b X \quad E[Y] = ?$$
=========================
$$\begin{aligned}
E[Y] & = \sum y \cdot P(Y=y) \\
 & = \sum (x b ) \cdot P(X b = x b) \\
 & = \sum (x b) \cdot P(X = x) \\
 & = b \cdot \left( \sum x \cdot P(X=x) \right ) \\
 & = b \cdot E[X] 
\end{aligned}$$

$$\text{(R) Let } Y = a + b X  \quad E[Y] = ?$$
=========================

We can combine these rules: 

$$\begin{aligned}
E[Y] & = E[a + b X] \\
     & = a + E[ b  X] \\
     & = a + b \cdot E[X]
\end{aligned}$$

An example
===========
incremental: true

At StatsPie, the number of toppings on the typical pizza is a random variable X having a mean value of 3. The cost of a pizza is $10 plus $1.50 per topping. How much does the average customer spend on a pizza?

$$\begin{aligned}
E[X] & = 3  & 
Y & = 10 + 1.5 X
\end{aligned}$$

$$\begin{aligned}
E[Y] & = E[10 + 1.5 X] \\
  & = 10 + 1.5 \cdot E[X] \\
  & = 10 + 1.5 \cdot 3 = 14.50
\end{aligned}$$

implying the average pizza costs $14.50.

Variance
========
Let the **variance** of the random variable $X$ be defined as

$$
\text{Var}[X] = E\left[ \left(X - E[X]\right)^2 \right]
$$

i.e. the **expected value** of the **squared distance from the mean**.

Using the rules for expected values we derive the following identity: 

$$
\text{Var}[X] = E[X^2] ~ - ~ \left( E[X] \right)^2 
$$

which is easier to calculate by hand.

Example
========
$$\begin{aligned}
\text{Var}[X] & = E[X^2] ~ - ~ \left( E[X] \right)^2 \\
% E[X] & = \sum_{x \in S} x \cdot P(X = x) \\
% E[X^2] & = \sum_{x \in S} x^2 \cdot P(X = x) 
\end{aligned}$$



```r
x       |   0|   1|   2|   3|   4|   5|
--------+----+----+----+----+----+----|
P(X = x)| .28| .37| .23| .09| .02| .01|
```

$$\begin{aligned}
E[X] & = \sum_{x \in S} x \cdot P(X = x) \\
   & = ~ 0 \times .28 + 1 \times .37 + 2 \times .23  \\
   &   ~ + \! 3 \times .09 + 4 \times .02 + 5 \times .01 \\
   & = 1.23
\end{aligned}$$


Example
========
$$\begin{aligned}
\text{Var}[X] & = E[X^2] ~ - ~ \left( E[X] \right)^2 \\
% E[X] & = \sum_{x \in S} x \cdot P(X = x) \\
% E[X^2] & = \sum_{x \in S} x^2 \cdot P(X = x) 
\end{aligned}$$



```r
x       |   0|   1|   2|   3|   4|   5|
--------+----+----+----+----+----+----|
P(X = x)| .28| .37| .23| .09| .02| .01|
```

$$\begin{aligned}
E[X^2] & = \sum_{x \in S} x^2 \cdot P(X = x) \\
   & = ~ 0^2 \times .28 + 1^2 \times .37 + 2^2 \times .23  \\
   &   ~ + \! 3^2 \times .09 + 4^2 \times .02 + 5^2 \times .01 \\
  & =  2.67
\end{aligned}$$

Example
========
$$\begin{aligned}
E[X] & = 1.23 &
E[X^2] & = 2.67
\end{aligned}$$


```r
x       |   0|   1|   2|   3|   4|   5|
--------+----+----+----+----+----+----|
P(X = x)| .28| .37| .23| .09| .02| .01|
```

$$\begin{aligned}
\text{Var}[X] & = E[X^2] -  \left( E[X] \right)^2 \\
 & = 2.67 - (1.23)^2 \\
 & = 1.16
\end{aligned}$$

implying that college students change their majors on average 1.23 times with a **variance** of 1.16 "times-squared".

"Times-squared" is a weird unit
=============================

Let the **standard deviation** be the square root of the variance. 

$$\text{sd}[X] = \sqrt{\text{Var}[X]}$$

Example: 

$$\begin{aligned}
\text{sd}[X] & = \sqrt{\text{Var}[X]} \\
 & = \sqrt{1.16}
 & = 1.078
\end{aligned}$$

implying that college students change their majors on average 1.23 times with a **standard deviation** of 1.08 times.


Rules for standard deviation
============================
Using the rules for expectations, we can show that:

$$\text{Var}[a + bX] = b^2 \cdot \text{Var}[X]$$

Therefore 

$$\text{sd}[a + bX] = b \cdot \text{sd}[X]$$


Example
=========
At StatsPie, the number of toppings on the typical pizza has a mean value of 3 with a standard deviation of 1/2. The cost of a pizza is $10 plus $1.50 per topping. 

What are the mean and standard deviation of the distribution of pizza cost? 

$$\begin{aligned}
E[X] & = 3  & 
\text{sd}[X] & = 0.5 \\
Y & = 10 + 1.5 X \\
E[Y] & = ? & \text{sd}[Y] & = ?
\end{aligned}$$

Example
=======
$$\begin{aligned}
E[X] & = 3  & 
\text{sd}[X] & = 0.5 \\
Y & = 10 + 1.5 X \\
\end{aligned}$$

Recall that $E[Y] = 14.50$.

Find the standard deviation: 

$$\begin{aligned}
\text{sd}[Y] & = \text{sd}[10 + 1.5 X] \\
  & = 1.5 \cdot \text{sd}[X]  \\
  & = 1.5 \cdot 0.5 = .75
\end{aligned}$$

Example
=========
incremental: true

At StatsPie, the number of toppings on the typical pizza has a mean value of 3 with a standard deviation of 1/2. The cost of a pizza is $10 plus $1.50 per topping. 

What are the mean and standard deviation of the distribution of pizza cost? 

$$\begin{aligned}
E[Y] & = 14.50 & 
\text{sd}[Y] & = .75 
\end{aligned}$$

implying that the pizza typically costs an average of $14.50 with a standard deviation of $0.75. 


Adding two random variables
===========================
Let $X$ and $Y$ be random variables and 
define $Z = X + Y$ and $Q = X - Y$.

It can be shown that, in all cases:

$$\begin{aligned} 
E[Z] & = E[X] + E[Y] \\
E[Q] & = E[X] - E[Y]
\end{aligned}$$

And, **if and only if X and Y are independent**, that 

$$\begin{aligned}
\text{Var}[Z] & = \text{Var}[X] + \text{Var}[Y]\\
\text{Var}[Q] & = \text{Var}[X] + \text{Var}[Y]
\end{aligned}$$


Standard deviations do not add
===========================

**If and only if X and Y are independent**, then

$$\begin{aligned}
\text{Var}[Z] & = \text{Var}[X] + \text{Var}[Y]\\
\text{Var}[Q] & = \text{Var}[X] + \text{Var}[Y]
\end{aligned}$$

Further note that, **iff X and Y are independent**
$$\begin{aligned}
\text{sd}[Z] & = \sqrt{\text{Var}[X] + \text{Var}[Y]}\\
\text{sd}[Q] & = \sqrt{\text{Var}[X] + \text{Var}[Y]}
\end{aligned}$$

> Standard deviations **DO NOT** add.

What if X and Y are dependent?
====================================

**Not covered in Stat 202.** 

Answer: 

Let $X$ and $Y$ be random variables and 
define $Z = aX + bY + c$.

$$\text{Var}[Z] = a^2 \cdot \text{Var}[X] + b^2 \cdot \text{Var}[Y] - 2ab \cdot \text{Cov}[X,Y]$$

where 

$$\text{Cov}[X,Y] = E\big[ \left( X - E[X] \right) \cdot \left( Y - E[Y] \right) \big]$$ 


Agenda 
==========
1. Homework comments
2. Checkpoints #12 result
3. Lecture 11 (covers pp. 128-155)   
    + Checkpoint 13: Exception and variance rules
    + **Checkpoint 15: Normal random variables**

Transition to continuous RVs
==============

IQ: 2 categories 
![plot of chunk unnamed-chunk-7](lecture11-figure/unnamed-chunk-7.png) 
***

IQ: 3 categories
![plot of chunk unnamed-chunk-8](lecture11-figure/unnamed-chunk-8.png) 

Transition to continuous RVs
==============
and lots more...
![plot of chunk unnamed-chunk-9](lecture11-figure/unnamed-chunk-9.png) 
***
and infinitely more...
![plot of chunk unnamed-chunk-10](lecture11-figure/unnamed-chunk-10.png) 

Density curves
===============
**A normal density**
![plot of chunk unnamed-chunk-11](lecture11-figure/unnamed-chunk-11.png) 

***
A density curve is the limit of a probability histogram. 

* The area under the curve is the **probability**. 
* The total area is 1.

For now, we study a special case: 

  * **normal distributions**

Normal Distributions
====================
incremental: true

If $X$ is a **normally distributed** random variable: 

  * $X + a$ is also normally distributed 
  * $bX$ is also normally distributed
  * $a + bX$ is also normally distributed. 

A normal distribution is completely defined by its **mean** and its **variance**. 

  * finding the distribution of $a + bX$ is as simple as using the $E[...]$ 
    and $\text{Var}[...]$ rules.

Example
=======
incremental: true

Let $X$ be normally distributed with mean 100 and variance of 9.

$$X \sim N(100, 9)$$ 

What is the distribution of $A = X-100$?

$$E[A] = E[X-100] = E[X] - 100 = 100 - 100 = 0$$

$$\text{Var}[A] = \text{Var}[X-100]=\text{Var}[X]=9$$

Therefore, $A$ is normally distributed with a mean of 0 and a variance of 9.

$$A \sim N(0,9)$$

Example
=======
incremental: true

Let $X$ be normally distributed with mean 100 and standard deviation 9. $A = X-100$ then has a mean of 0 and a variance of 9. 

$$X \sim N(100,9) \quad \quad A \sim N(0,9)$$

What is the distribution of $B = \frac{A}{\sqrt{9}} = \frac{X-100}{\sqrt{9}}$?

$$E[B] = E[\frac{A}{\sqrt{9}}] = \frac{1}{\sqrt{9}}E[X] = \frac{1}{\sqrt{9}} \cdot 0 = 0$$

$$\text{Var}[B] = \text{Var}[\frac{A}{\sqrt{9}}]=\left(\frac{1}{\sqrt{9}}\right)^2\text{Var}[A]=\frac{1}{9}\cdot 9 = 1$$

Therefore, $B$ is normally distributed with a mean of 0 and a standard deviation of 1. 

$$B \sim N(0,1)$$

Example
=======
Let $X$ be normally distributed with mean 100 and standard deviation 9. $A = X-100$ then has a mean of 0 and a variance of 9. 

$$X \sim N(100,9) \quad \quad A \sim N(0,9)$$

What is the distribution of $B = \frac{A}{\sqrt{9}} = \frac{X-100}{\sqrt{9}}$?

$$E[B] = 0 \quad \quad \text{Var}[B] = 1$$

Therefore, $B$ is normally distributed with a mean of 0 and a standard deviation of 1. 

$$B \sim N(0,1)$$


The standard normal distribution
================================
Any normal distribution can be transformed to a standard normal

Let $X \sim N(\mu, \sigma^2)$ where $\mu$ is the mean and $\sigma^2$ the variance.

Let 
  $$Z = \frac{X - E[X]}{\text{sd}[X]} = \frac{X - \mu}{\sqrt{\sigma^2}} $$
  
$Z$ is a standard normal, its mean is zero and its variance is 1. 

A std normal uses sd as a ruler
=====================================
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the z-score for a pizza that will use at least 7 oz of cheese? 

Let $X \sim N(6, 1/4)$ and $Z = \frac{X - 6}{\sqrt{1/4}}$

If $X = 7$ then $Z = ?$

$$Z = \frac{7-6}{\sqrt{1/4}} = \frac{1}{1/2} = 2$$

implying that 7 is two standard deviations from the mean. 


Recall: the 68-95-99.7 rule
===================
![plot of chunk unnamed-chunk-12](lecture11-figure/unnamed-chunk-12.png) 
***

Percentages of observations: 
 * 68% within 1 sd 
 * 95% within 2 sd
 * 99.7% within 3 sd
 
An example
===============
incremental: true

At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7 oz of cheese? 

"at least 7 oz of cheese" means $X \ge 7$

$$P(X \ge 7) = ?$$

Convert $x=7$ to a z-score: $z = \frac{7-6}{\sqrt{1/2}} = 2$

implying that $x = 7$ oz is $z = 2$ standard deviations from the mean. 

An example
===============
incremental: true

![plot of chunk unnamed-chunk-13](lecture11-figure/unnamed-chunk-13.png) 
***

$P(X \ge 7) = P(Z \ge 2) = ?$

The probability of $Z$ being greater than or equal to 2 is the shaded area.

The 68-95-99.7 rule says that 95% of observations are within 2 sd.

Therefore 2.5% of observations are **above** 2 sd.

An example
===========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7 oz of cheese? 

$P(X \ge 7) = P(Z \ge 2) = .025$

implying that 2.5% of pizza will use at least 7 oz of cheese.


A Stat 202 rule of thumb
==============

> **Typical** values of a random variable are 
> within 2 standard deviations of the mean. 

* The 68–95–99.7 rule states that 95% of observations from a **normal distribution** are within two standard deviations of the mean. 

* [Chebyshev's inequality](http://en.wikipedia.org/wiki/Chebyshev's_inequality) (not covered in Stat 202) states that **at least** 75% of observations from **any probability distribution** are within two standard deviations of the mean. 


An further example
===========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7.34 oz of cheese? 

$$\begin{aligned}
P(X \ge 7.34) & = P(X - 6 \ge 7.34 - 6) \\
  & = P(\frac{X - 6}{\sqrt{1/4}} \ge \frac{7.34 - 6}{\sqrt{1/4}}) \\ 
  & = P(Z \ge 2.68 )
\end{aligned}
$$

where $Z$ is distributed as a standard normal.

Extending the 68–95–99.7 rule
=============================

![plot of chunk unnamed-chunk-14](lecture11-figure/unnamed-chunk-14.png) 
***

We know that  $P(Z \ge 2.68 )$ will be somewhere between 2.5% and 0.15%.

What is it? 

* A famous result in calculus is that **there is no closed form formula** for 
  the area under a normal curve.
  
* Use a table (or software)

A standard normal table
========================

![plot of chunk unnamed-chunk-15](lecture11-figure/unnamed-chunk-15.png) 
***

Gives the area to the left of $z$.

To use: 

1. Express your z-score as **less than**.
1. Find the **row** with the first two digits of $z$.
2. Find the **column** with the third digit of $z$
3. Read off the value. 

Best explained by [looking at one](Normal Table.html).

Example
========

Step 1: 

$P(Z \ge 2.68 ) = 1 - P(Z \le 2.68 )$

Step 2: $2.68 = 2.6 + 0.08$ find $2.6$

z  | .00	|.01	|.02	|.03	|.04	|.05	|.06	|.07	|.08	|.09 |
---|------|-----|-----|-----|-----|-----|-----|-----|-----|----|
2.5|	.9938	|.9940|	.9941	|.9943	|.9945	|.9946	|.9948	|.9949 |	.9951	| .9952|
2.6|	.9953	|.9955|	.9956	|.9957	|.9959	|.9960	|.9961	|.9962 |.9963|	.9964 |
2.7|	.9965 |	.9966|	.9967|	.9968|	.9969|	.9970|	.9971|	.9972|	.9973|	.9974|

We want:

z  | .00  |.01	|.02	|.03	|.04	|.05	|.06	|.07	|.08	|.09 |
---|------|-----|-----|-----|-----|-----|-----|-----|-----|----|
2.6|	.9953	|.9955|	.9956	|.9957	|.9959	|.9960	|.9961	|.9962 |.9963|	.9964 |



Example
========

Step 1: $P(Z \ge 2.68 ) = 1 - P(Z \le 2.68 )$

Step 2: $2.68 = 2.6 + 0.08$ find $2.6$

z  | .00  |.01	|.02	|.03	|.04	|.05	|.06	|.07	|.08	|.09 |
---|------|-----|-----|-----|-----|-----|-----|-----|-----|----|
2.6|	.9953	|.9955|	.9956	|.9957	|.9959	|.9960	|.9961	|.9962 |.9963|	.9964 |

Step 3: $2.68 = 2.6 + 0.08$ find $0.08$

z  | .08	|
---|------|
2.6| .9963|	

Solve: 

$P(Z \ge 2.68 ) = 1 - P(Z \le 2.68 ) = 1 - .9963 = 0.0037$

Pulling it together 
===================

At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7.34 oz of cheese? 

$$\begin{aligned}
P(X \ge 7.34) & = P(Z \ge 2.68 ) \\
 & = 1 - P(Z \le 2.68 ) \\
 & = 1 - .9963 = 0.0037
\end{aligned}
$$

implying that only 0.37% of pizzas will use at least 7.34 oz of cheese. 

Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7.34 oz of cheese? 

Find the z-score:

```r
(7.34-6)/sqrt(1/4) 
```

```
[1] 2.68
```


Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7.34 oz of cheese? 

Lookup $P(Z \le 2.68)$


```r
pnorm( 2.68 )
```

```
[1] 0.9963
```

Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of 1/4 oz. What is the probability that a pizza will use at least 7.34 oz of cheese? 

Find $P(Z \ge 2.68) = 1 - (Z \le 2.68)$


```r
1 - pnorm( 2.68 )
```

```
[1] 0.003681
```

implying that 0.37% of pizzas use at least 7.34 oz of cheese.


Going the other way
===================
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. How much cheese would the top 10% of pizzas contain? 

We know that:

$$P(X \ge x) = .1$$

what is $x$? 


Going the other way
===================

$$\begin{aligned}
P(X \ge x) & = .10 \\
 & = P(\frac{X - 6}{\sqrt{1/4}} \ge \frac{x - 6}{\sqrt{1/4}}) \\
 & = P(Z \ge z ) = .10 
\end{aligned}$$

To find the correct $z$ value we express it as less than:

$$P(Z \ge z) = .1 = 1 - P(Z \le z)$$

Implying that we need to lookup

$$P(Z \le z) = 1 - .1 = .90$$

in our table. 

Going the other way
===================
$$P(Z \le z) = 1 - .0001 = .90$$

z  | .00  |.01  |.02	|.03	|.04	|.05	|.06	|.07	|.08	|.09 |
---|------|-----|-----|-----|-----|-----|-----|-----|-----|----|
1.2|	.8849|	.8869	|.8888	|.8907	|.8925  |.8944	|.8962|	.8980|	.8997|	.9015|
1.3|	.9032|	.9049	|.9066	|.9082	|.9099	|.9115	|.9131|	.9147	|.9162|	.9177|

That is somewhat unsatisfying... 

 * $P(Z \le 1.28) = .8997$ and
 * $P(Z \le 1.29) = .9015$
 
Choose $1.28$ as its probability is closer to .90.

Going the other way
===================

We wanted: $P(Z \le z) = 1 - .1 = .90$

We have: $P(Z \le 1.28) = .8997$. 

Just go with it. Therefore: 
$$\begin{aligned}
P(X \ge x) & = .10 \\
 & = P(\frac{X - 6}{\sqrt{1/4}} \ge \frac{x - 6}{\sqrt{1/4}}) \\
 & = P(Z \ge 1.28 ) = .10 
\end{aligned}$$

So solve: $\frac{x - 6}{\sqrt{1/4}} = 1.28$

Going the other way
===================
$$\frac{x - 6}{\sqrt{1/4}}  = 1.28$$

Implies 
$$ x = 6 + 1.28 \sqrt{1/4} = 6.64$$


Pulling it together
===========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. How much cheese would the top 10% of pizzas contain? 

$$P(X \ge x) = .1$$

$$ x = 6 + 1.28 \sqrt{1/4} = 6.64$$

implies that at least 6.64 oz of cheese are used to make the top 10% of pizzas. 

Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. How much cheese would the top 10% of pizzas contain? 

$$P(X \ge x) = .1$$

Express the z-score probability as a less than: 

$$P(Z \ge z) = 1 - P(Z \le z) = .1$$ 

$P(Z \le z) = .90$

Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. How much cheese would the top 10% of pizzas contain? 

Look $P(Z \le z) = .90$ up in R


```r
qnorm(.90)
```

```
[1] 1.282
```

implying that the z score is $1.282$. 

Using R
========
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. How much cheese would the top 10% of pizzas contain? 

Convert $z = 1.282$ to the units of X. 


```r
6 + sqrt(1/4) * 1.282 
```

```
[1] 6.641
```

implying that the top 10% of pizzas use at least $6.64$ of cheese.  

A further example
=================
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. What is the probability of getting a pizza that has between 5.4 and 6.7 ounces of chese? 

$$P(5.4 \le X \le 6.7) = ?$$

Draw a picture to express it in terms of "less than":

$$P(5.4 \le X \le 6.7) = P(X \le 6.7) - P(X \le 5.4) $$

Picture
=======
![plot of chunk unnamed-chunk-21](lecture11-figure/unnamed-chunk-21.png) 
***
$$\begin{aligned}
P(& 5.4 \le X \le 6.7) = \\ 
  & P(X \le 6.7) - P(X \le 5.4)
  \end{aligned}$$

Since you already know how to solve the "less than" problems, you 
can solve this problem too. 

Solution
=========
$P(X \le 6.7) = P(\frac{X-6}{\sqrt{1/4}} \le \frac{6.7-6}{\sqrt{1/4}}) = P(Z \le 1.4)$


```r
pnorm(1.4)
```

```
[1] 0.9192
```

$P(X \le 5.4) = P(\frac{X-6}{\sqrt{1/4}} \le \frac{5.4-6}{\sqrt{1/4}}) = P(Z \le -1.2)$


```r
pnorm(-1.2)
```

```
[1] 0.1151
```


Pulling it together
=================
At StatsPie, the amount of cheese used to make a typical pizza is normally distributed with a mean value of 6 oz with a variance of ¼ oz. What is the probability of getting a pizza that has between 5.4 and 6.7 ounces of chese? 

$$\begin{aligned}
P(5.4 \le X \le 6.7) & = P(X \le 6.7) - P(X \le 5.4) \\
 & = 0.9192 - 0.1151 \\
 & = 0.8041
 \end{aligned}$$

implying that 80% of pizzas contain between 5.4 and 6.7 oz of cheese.

Normal Summary
==============

Normal problems look something like this: 

* Convert to a standard normal
* Express the probabilities in terms of less than 
* Lookup either the probability or z-score in the table 
* Convert back to the original distribution (if needed)


Fun Calculus fact
==========================
The density function of a normal random variable with a mean of $\mu$ and a standard deviation $\sigma$ is 
$$ 
f(x) = \frac{1}{\sigma \sqrt{2\pi }} e^{- \frac{(x-\mu)^2}{2\sigma^2}}
$$

The probability of $X$ being between two constants $a$ and $b$ is: 
$$ 
P(a \le X \le b) = \int_a^b \frac{1}{\sigma \sqrt{2\pi }} e^{- \frac{(x-\mu)^2}{2\sigma^2}} dx
$$ 

This integral has **no closed form solution**.

> I **cannot** give you a non-integral formula.
