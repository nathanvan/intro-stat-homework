Stat 202: Lecture 2 (covers pp. 22-33)
========================================================
author: Nathan VanHoudnos
date: 9/26/2014
transition: none

Agenda 
==========
1. Homework #1 comments
2. Checkpoint #1 results 
3. Lecture 2 (covers pp. 22-33)

Homework #1 comments 
====================
* Having laptop problems? Go to Laptop ER: 
     + 1:00 - 4:00 p.m. **today** 
     + at Norris University Center, across from the University bookstore
     + first-come-first serve
     + info: http://www.it.northwestern.edu/laptoper/
* NU IT is installing R & RStudio in the library 
     + This will **not** be ready until after HW 1 is due.      
     + If you can't get them installed on your machine, then **borrow** a friend's
       machine for this assignment. (**Do your own assignment!**)

Homework #1 comments 
====================     
* If the \*.Rmd file does not open when you double-click on it, 
  then **open** it directly in RStudio. (Demo)

* Follow the directions on the homework.
    + Steps 1-4: Make sure that RStudio is working 
    + Step 7: Saves you time: 

> Step 7: After every question, click the **Knit HTML** button to make sure that 
> the output is as expected.
    


Homework #1 comments 
====================     
* Asking me questions is encouraged. I will respond! 

* However, **it is disrespectful to waste my time.**
    + Do not ask me questions that you can answer yourself with a little bit of effort. 
    + *"Thanks, I already figured it out."* implies that you did not need to ask the
      question! 
 
Agenda 
==========
1. Homework #1 comments
2. Checkpoint #1 results 
3. Lecture 2 (covers pp. 22-33)

Checkpoint #1 results
==================
**Academic integrity** 
 * The checkpoints are **quizzes**, they are to be your work **alone**.
 * I will update the syllabus to clarify

**Notes** 
 * 68 of 75 students have signed up on OLI
 * 64 of 68 took the Checkpoint
    + 1 student took Checkpoint \#2 instead
 * Average percent correct: **90%**
 * If you have questions, see me or Aaron

Agenda 
==========
1. Homework #1 comments
2. Checkpoint #1 results 
3. Lecture 2 (covers pp. 22-33)

Motivation for today: 
=============================

![plot of chunk unnamed-chunk-2](lecture2-figure/unnamed-chunk-2.png) 
*** 
These two distributions have ...
* the same shape 
* the same center 
* **different spreads**
   + Range
   + Inter-quartile range (IQR)
   + Standard deviation 

Measures of spread 
==================
left: 40%

**Age at Oscar**

```
  2 | 1
  2 | 56669
  3 | 013333444
  3 | 555789
  4 | 11123
  4 | 599
  5 | 
  5 | 
  6 | 1
  6 | 
  7 | 4
  7 | 
  8 | 0
```
**** 
* **Range:**
     + Max - Min  
     + 80 - 21 = 59
     + *All* data in range
* **Inter-Quartile Range**
     + 50% of data $\le$ **median**
     + 25% of data $\le$ **Q1** 
     + 75% of data $\le$ **Q3** 
     + **IQR** = Q3 - Q1
     + *50%* of data in IQR 

IQR by hand example 
=======================
**Lowest** 

```
  2 | 1
  2 | 56669
  3 | 013333444
  3 | 5
```
**Highest**

```
  3 | 55789
  4 | 11123599
  5 | 
  6 | 1
  7 | 4
  8 | 0
```
*** 
* Q1 $\approx$ median of lowest half
    + 32
* Q3 $\approx$ median of highest half
    + 41.5 
* IQR $\approx$ 41.5 - 32
    + 9.5 years
  
IQR by R example 
=========

```r
head(oscars.df, n=3) ## First three records
```

```
  year age
1 1970  34
2 1971  34
3 1972  26
```

```r
summary(oscars.df$age)
```
<pre><code><small>   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
   21.0    32.5    35.0    38.5    41.2    80.0 
</small></code></pre>
**However**: 41.2 - 32.5 = 8.7 $\ne$ 9.5

R and "by hand" disagree!
==================
incremental: true

This is **earth-shattering**.

> Is R wrong? **or** Am I teaching you lies?

Answer: **Neither.**

* R implements **nine** methods (including "by hand") to calculate quartiles

* Some methods are better **estimators** than others 

* The default of `summary()` is among the best

* The "by hand" method is among the worst


Q1, Q3, and IQR are a little tricky
=================================
OLI textbook, p. 24, emphasis mine: 

> Note that Q1 and Q3 as reported by the various software packages differ 
> from each other and are also slightly different from the ones we
> found [by hand]. **This should not worry you.**

**It should pique your intellectual curiosity.**

For this course, I will ask you to use
  * the "by hand" method for tests & quizzes, and
  * the R `summary` method for homeworks.


Using IQR: Outliers
===================
Outliers are suspected if an observation is 
   *  below $\left( \text{Q1} - 1.5 \times \text{IQR}\right)$ or
   *  above $\left( \text{Q3} + 1.5 \times \text{IQR}\right)$ 

![a](spread10.gif)


Example: 1.5 IQR rule
=======
incremental: true
left:40%

**Age at Oscar**

```
  2 | 1
  2 | 56669
  3 | 013333444
  3 | 555789
  4 | 11123
  4 | 599
  5 | 
  5 | 
  6 | 1
  6 | 
  7 | 4
  7 | 
  8 | 0
```
**** 
Recall 
 * Q1 = 32 and Q3 = 41.5
 
Which data points, if any, are suspected outliers?
 * IQR = 41.5 - 32 = 9.5
 * 1.5 IQR = 14.25
 * Q1 - 1.5 IQR = 17.75
 * Q3 + 1.5 IQR = 55.75
 * suspect 61, 74, and 80
 
 
Handling outliers: It depends
=============================

Roughly three types of outliers:

1. Same data-generating process
2. Different data-generating process
3. Mistakes 

Outlier from same process
============================
left: 65%

![a](spread21.gif)
****
**Earthquakes**

* the largest quakes can be the most important! 
* removing such a data point might be a terrible idea

Outlier from different process
============================
left: 65%

![a](spread22.gif)
***
**Stock Prices**

* Highly-publicized anti-smoking congressional hearings
* Large negative pressure for stock price
* Can remove outlier **if** interested in typical returns


Outlier from mistake
=====================
left: 65%

![a](spread23.gif)
***
**Archaeology**

* Likely that '.394' was really '.094'

* Often **useful** to remove outlier

Outlier from mistake
=====================
left: 65%

![a](spread24.gif)
***
**Archaeology**

* Likely that '.394' was really '.094'

* Often **useful** to remove outlier

Boxplots: 5 number summary
=================================
left:40%

**Age at Oscar**

```
  2 | 1
  2 | 56669
  3 | 013333444
  3 | 555789
  4 | 11123
  4 | 599
  5 | 
  5 | 
  6 | 1
  6 | 
  7 | 4
  7 | 
  8 | 0
```
***
**5 number summary**
<pre><code><small>Min. Q1  Median Q3   Max.
21   32  35     41.5 80</small></code></pre>
**Boxplot**
![a](buildboxplot.png)


Boxplots in R 
=====================

```r
summary(oscars.df$age)
```
<pre><code><small>   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
   21.0    32.5    35.0    38.5    41.2    80.0 
</small></code></pre>

```r
boxplot(oscars.df$age)
```
![plot of chunk unnamed-chunk-15](lecture2-figure/unnamed-chunk-15.png) 


BRFSS Boxplots
=========================
incremental: true


**Height in inches**
![plot of chunk unnamed-chunk-17](lecture2-figure/unnamed-chunk-17.png) 
***
What is the height of 

* the tallest person? 
    + 93 in. (7' 9")
* the shortest person? 
    + 48 in. (4')

I am taller than 3/4 of people. How tall am I?    
  * Q3 = 70 in. (5' 10")

BRFSS Boxplots
=====================
incremental:true

**Age**
![plot of chunk unnamed-chunk-18](lecture2-figure/unnamed-chunk-18.png) 
***
Is this distribution symmetric, right-skewed, or left-skewed? 
 * **right-skewed** 

Approximately what percentage of people are under 60?
 * **A little over 75%** 
 

Side-by-side Boxplots
=====================
**Age**
![plot of chunk unnamed-chunk-19](lecture2-figure/unnamed-chunk-19.png) 
***
**Age by General Health**
![plot of chunk unnamed-chunk-20](lecture2-figure/unnamed-chunk-20.png) 

Side-by-side Boxplots
=====================
**Age by General Health**
![plot of chunk unnamed-chunk-21](lecture2-figure/unnamed-chunk-21.png) 
***
Compare and contrast
* **Shape**
    + Excellent: right-skewed 
    + Poor: symmetric  
* **Center**
    + Excellent: typically 40 years
    + Poor: typically 60 years

Side-by-side Boxplots
=====================
**Age by General Health**
![plot of chunk unnamed-chunk-22](lecture2-figure/unnamed-chunk-22.png) 
***
Compare and contrast
* **Spread** 
    + Both groups have similar IQR 
    + Nearly 75% of people in excellent health are younger than 
      than the youngest 25% of people in poor health. 

Side-by-side Boxplots
=====================
**Age by General Health**
![plot of chunk unnamed-chunk-23](lecture2-figure/unnamed-chunk-23.png) 
***
Compare and contrast
* **Deviations from pattern** 
    + The oldest people rate themselves in excellent health. 
    + These outliers are **likely** to occur again and should be kept.
    

Tell me a story...
=====================
**Weight by gender**
![plot of chunk unnamed-chunk-24](lecture2-figure/unnamed-chunk-24.png) 
***
**Desired Weight**
![plot of chunk unnamed-chunk-25](lecture2-figure/unnamed-chunk-25.png) 



Motivation for today: 
=============================
![plot of chunk unnamed-chunk-26](lecture2-figure/unnamed-chunk-26.png) 
*** 
These two distributions have ...
* the same shape 
* the same center 
* different spreads
   + Range
   + Inter-quartile range (IQR)
   + **Standard deviation**

Standard deviation: Calculation
===============================
<!-- html table generated in R 3.1.1 by xtable 1.7-1 package -->
<!-- Fri Sep 26 12:42:43 2014 -->
<TABLE border=1>
  <TR> <TD align="right"> Data_D </TD> <TD align="right">   7 </TD> <TD align="right">   9 </TD> <TD align="right">   5 </TD> <TD align="right">  13 </TD> <TD align="right">   3 </TD> <TD align="right">  11 </TD> <TD align="right">  15 </TD> <TD align="right">   9 </TD> </TR>
   </TABLE>
Step 1. Find the mean ($\bar{x} = 9$).

Step 2. Find the deviations from the mean: 
<TABLE border=1>
  <TR> <TD align="right"> Deviations </TD> <TD align="right">  -2 </TD> <TD align="right">   0 </TD> <TD align="right">  -4 </TD> <TD align="right">   4 </TD> <TD align="right">  -6 </TD> <TD align="right">   2 </TD> <TD align="right">   6 </TD> <TD align="right">   0 </TD> </TR>
   </TABLE>
Step 3. Square the deviations: 
<TABLE border=1>
  <TR> <TD align="right"> Squared Deviations </TD> <TD align="right">   4 </TD> <TD align="right">   0 </TD> <TD align="right">  16 </TD> <TD align="right">  16 </TD> <TD align="right">  36 </TD> <TD align="right">   4 </TD> <TD align="right">  36 </TD> <TD align="right">   0 </TD> </TR>
   </TABLE>

Standard deviation: Calculation
===============================
<TABLE border=1>
  <TR> <TD align="right"> Data_D </TD> <TD align="right">   7 </TD> <TD align="right">   9 </TD> <TD align="right">   5 </TD> <TD align="right">  13 </TD> <TD align="right">   3 </TD> <TD align="right">  11 </TD> <TD align="right">  15 </TD> <TD align="right">   9 </TD> </TR>
  <TR> <TD align="right"> Deviations </TD> <TD align="right">  -2 </TD> <TD align="right">   0 </TD> <TD align="right">  -4 </TD> <TD align="right">   4 </TD> <TD align="right">  -6 </TD> <TD align="right">   2 </TD> <TD align="right">   6 </TD> <TD align="right">   0 </TD> </TR>
  <TR> <TD align="right"> Squared Deviations </TD> <TD align="right">   4 </TD> <TD align="right">   0 </TD> <TD align="right">  16 </TD> <TD align="right">  16 </TD> <TD align="right">  36 </TD> <TD align="right">   4 </TD> <TD align="right">  36 </TD> <TD align="right">   0 </TD> </TR>
   </TABLE>

Step 4: Sum the squared deviations ($112$).

Step 5: Divide the sum by $n-1$, i.e. one less than the sample size 
  $$\frac{112}{8 -1 } = 16 $$

  * This quantity is the **variance**.

Step 6: **Standard deviation** square root of variance ( sd = 4 )

Standard deviation: Comments
============================
* R will do a standard deviation calculation for you: 

```r
sd(Data_D)
```

```
[1] 4
```

* It is more important that you **understand the properties** of the standard deviation than that you can calculate it. 

* The standard deviation has useful properties for a **special** distribution: the **normal** distribution

Normal distributions
================================
**A normal distribution**
![plot of chunk unnamed-chunk-32](lecture2-figure/unnamed-chunk-32.png) 
***
Three characteristics of normal distributions:
 * unimodal,
 * symmetric, and
 * has no outliers.  

Normal distributions are **surprisingly** common.

SD Rule for Normal Distributions
===============
![a](sdgraph2.gif)
***
Approximately 
 * 68% within 1 sd of the mean.
 * 95% within 2 sd of the mean.
 * 99.7% (or virtually all) within 3 sd of the mean.


68/95/99.7 rule example:
========================
incremental: true

The body temperatures of dogs are normally distributed 
with a mean of 101.3 F and a standard deviation of 0.6 F.

* 95% of dogs fall in what temp range?
     + 101.3 - 2(.6) = 100.1 
     + 101.3 + 2(.6) = 102.5
* What percent of temps. are more than 101.1 F?
     + 95% between 100.1 F and 102.5 F
     + 2.5% below 100.1 F
     + 97.5% above 100.1 F

68/95/99.7 rule example:
========================
incremental: true

The body temperatures of dogs are normally distributed 
with a mean of 101.3 F and a standard deviation of 0.6 F.

* What percent of temps. are less than 99.5 F? 
     + 101.3 - 3(.6) = 99.5 
     + 101.3 + 3(.6) = 103.1
     + 97.7% are b/t 99.5 F and 103.1 F
     + 0.3% are outside that range 
     + 0.15% are less than 99.5 F
 
Comparing measures
==================
The **IQR** is to the **median** as the **standard deviation** is to the **mean**.

* Use the mean and standard deviation if a distribution is:
  + unimodal
  + symmetric, and 
  + has no outliers.
  
* Otherwise use the median and IQR.

* **SD Rule only if a distribution is normal.** 

Quick check: 
================================
incremental: true

![plot of chunk unnamed-chunk-33](lecture2-figure/unnamed-chunk-33.png) 
***
Mean and SD or Median and IQR?
  * Mean and SD 

Can we use the SD rule?
  * No. We were not told this is a normal distribution.
  

Quick check: 
================================
incremental: true

![plot of chunk unnamed-chunk-34](lecture2-figure/unnamed-chunk-34.png) 
***
Mean and SD or Median and IQR?
  * Median and IQR

Can we use the SD rule?
  * No. The distribution is skewed, therefore it is not normal.
  

